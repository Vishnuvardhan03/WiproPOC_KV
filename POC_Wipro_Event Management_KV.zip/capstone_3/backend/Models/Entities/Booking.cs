using EventManagementSystem.Domain.Enums;

namespace EventManagementSystem.Domain.Entities;

public class Booking : BaseEntity
{
    public Guid EventId { get; set; }
    public Event Event { get; set; } = null!;

    public Guid AttendeeId { get; set; }
    public User Attendee { get; set; } = null!;

    public BookingStatus Status { get; set; } = BookingStatus.Pending;
    public string TicketNumber { get; set; } = string.Empty;
    public DateTime? CheckedInAtUtc { get; set; }
    public DateTime? CancelledAtUtc { get; set; }
    public Payment? Payment { get; set; }
}
