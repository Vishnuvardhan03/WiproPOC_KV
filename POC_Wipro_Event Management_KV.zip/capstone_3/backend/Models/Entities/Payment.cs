using EventManagementSystem.Domain.Enums;

namespace EventManagementSystem.Domain.Entities;

public class Payment : BaseEntity
{
    public Guid BookingId { get; set; }
    public Booking Booking { get; set; } = null!;

    public decimal AmountInRupees { get; set; }
    public string Currency { get; set; } = "INR";

    public string ProviderOrderId { get; set; } = string.Empty;
    public string ProviderPaymentId { get; set; } = string.Empty;
    public PaymentStatus Status { get; set; } = PaymentStatus.Pending;

    public DateTime? PaidAtUtc { get; set; }
    public string? FailureReason { get; set; }
}
