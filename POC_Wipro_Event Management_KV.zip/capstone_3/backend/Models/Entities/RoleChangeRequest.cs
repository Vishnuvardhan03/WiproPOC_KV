using EventManagementSystem.Domain.Enums;

namespace EventManagementSystem.Domain.Entities;

public class RoleChangeRequest : BaseEntity
{
    public Guid UserId { get; set; }
    public User User { get; set; } = null!;

    public UserRole RequestedRole { get; set; } = UserRole.Attendee;
    public RoleRequestStatus Status { get; set; } = RoleRequestStatus.Pending;

    public Guid? ReviewedByAdminId { get; set; }
    public User? ReviewedByAdmin { get; set; }
    public DateTime? ReviewedAtUtc { get; set; }

    public string? AdminComment { get; set; }
}
