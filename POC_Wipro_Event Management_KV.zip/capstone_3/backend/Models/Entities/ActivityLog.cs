namespace EventManagementSystem.Domain.Entities;

public class ActivityLog : BaseEntity
{
    public Guid? ActorUserId { get; set; }
    public User? ActorUser { get; set; }

    public string Action { get; set; } = string.Empty;
    public string EntityType { get; set; } = string.Empty;
    public Guid? EntityId { get; set; }
    public string Metadata { get; set; } = string.Empty;
}
