using EventManagementSystem.Domain.Enums;

namespace EventManagementSystem.Domain.Entities;

public class User : BaseEntity
{
    public string FullName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public byte[] PasswordHash { get; set; } = Array.Empty<byte>();
    public byte[] PasswordSalt { get; set; } = Array.Empty<byte>();
    public UserRole Role { get; set; } = UserRole.Attendee;

    public ICollection<Event> OrganizedEvents { get; set; } = new List<Event>();
    public ICollection<Booking> Bookings { get; set; } = new List<Booking>();
    public ICollection<RoleChangeRequest> RoleChangeRequests { get; set; } = new List<RoleChangeRequest>();
    public ICollection<EventChangeRequest> EventChangeRequests { get; set; } = new List<EventChangeRequest>();
    public ICollection<Notification> Notifications { get; set; } = new List<Notification>();
    public ICollection<ActivityLog> ActivityLogs { get; set; } = new List<ActivityLog>();
}
