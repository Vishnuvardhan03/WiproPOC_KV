using EventManagementSystem.Domain.Enums;

namespace EventManagementSystem.Domain.Entities;

public class EventChangeRequest : BaseEntity
{
    public Guid EventId { get; set; }
    public Event Event { get; set; } = null!;

    public Guid RequestedByOrganizerId { get; set; }
    public User RequestedByOrganizer { get; set; } = null!;

    public string Title { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public string Location { get; set; } = string.Empty;
    public DateTime StartDateUtc { get; set; }
    public DateTime EndDateUtc { get; set; }
    public int Capacity { get; set; }
    public decimal PriceInRupees { get; set; }

    public EventChangeRequestStatus Status { get; set; } = EventChangeRequestStatus.Pending;

    public Guid? ReviewedByAdminId { get; set; }
    public User? ReviewedByAdmin { get; set; }
    public DateTime? ReviewedAtUtc { get; set; }

    public string? AdminComment { get; set; }
}
