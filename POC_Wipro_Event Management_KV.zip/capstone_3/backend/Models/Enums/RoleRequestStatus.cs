namespace EventManagementSystem.Domain.Enums;

public enum RoleRequestStatus
{
    Pending = 1,
    Approved = 2,
    Rejected = 3
}
