namespace EventManagementSystem.Domain.Enums;

public enum BookingStatus
{
    Pending = 1,
    Booked = 2,
    Cancelled = 3,
    Declined = 4
}
