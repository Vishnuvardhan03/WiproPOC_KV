namespace EventManagementSystem.Domain.Enums;

public enum EventChangeRequestStatus
{
    Pending = 1,
    Approved = 2,
    Rejected = 3
}
