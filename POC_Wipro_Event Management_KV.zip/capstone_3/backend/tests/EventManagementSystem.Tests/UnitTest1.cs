using EventManagementSystem.Infrastructure.Security;

namespace EventManagementSystem.Tests;

public class PasswordHasherTests
{
    [Fact]
    public void HashPassword_WithValidPassword_ProducesDifferentHashAndSalt()
    {
        var hasher = new PasswordHasher();
        var resultA = hasher.HashPassword("StrongPassword#2026");
        var resultB = hasher.HashPassword("StrongPassword#2026");

        Assert.NotEqual(resultA.Hash, resultB.Hash);
        Assert.NotEqual(resultA.Salt, resultB.Salt);
    }

    [Fact]
    public void VerifyPassword_WithValidAndInvalidPassword_ReturnsExpectedResult()
    {
        var hasher = new PasswordHasher();
        var (hash, salt) = hasher.HashPassword("StrongPassword#2026");

        Assert.True(hasher.VerifyPassword("StrongPassword#2026", hash, salt));
        Assert.False(hasher.VerifyPassword("WrongPassword#2026", hash, salt));
    }
}