using EventManagementSystem.Application.Interfaces.Security;
using EventManagementSystem.Domain.Entities;
using EventManagementSystem.Domain.Enums;
using Microsoft.EntityFrameworkCore;
using Microsoft.Data.Sqlite;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace EventManagementSystem.Infrastructure.Persistence;

public static class DatabaseSeeder
{
    public static async Task MigrateAndSeedAsync(IServiceProvider serviceProvider, IConfiguration configuration)
    {
        using var scope = serviceProvider.CreateScope();
        var dbContext = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();

        if (dbContext.Database.ProviderName?.Contains("Sqlite", StringComparison.OrdinalIgnoreCase) == true)
        {
            await dbContext.Database.EnsureCreatedAsync();

            var hasEventsPriceColumn = await SqliteColumnExistsAsync(dbContext, "Events", "PriceInRupees");
            if (!hasEventsPriceColumn)
            {
                await dbContext.Database.EnsureDeletedAsync();
                await dbContext.Database.EnsureCreatedAsync();
            }
        }
        else
        {
            await dbContext.Database.MigrateAsync();
        }

        var enabled = configuration.GetValue<bool>("Database:SeedOnStartup");
        if (!enabled)
        {
            return;
        }

        // Skip if already seeded
        if (await dbContext.Users.AnyAsync())
        {
            return;
        }

        var passwordHasher = scope.ServiceProvider.GetRequiredService<IPasswordHasher>();
        var logger = scope.ServiceProvider.GetRequiredService<ILogger<ApplicationDbContext>>();

        var adminEmail    = configuration["Database:AdminEmail"]    ?? "admin@ems.local";
        var adminPassword = configuration["Database:AdminPassword"] ?? "Admin@12345";

        // Users
        User MakeUser(string fullName, string email, string password, UserRole role)
        {
            var (h, s) = passwordHasher.HashPassword(password);
            return new User { FullName = fullName, Email = email, PasswordHash = h, PasswordSalt = s, Role = role };
        }

        var admin      = MakeUser("System Administrator", adminEmail,               adminPassword, UserRole.Admin);
        var organizer1 = MakeUser("Alice Organizer",      "alice@ems.local",         "Organizer@123", UserRole.Organizer);
        var organizer2 = MakeUser("Bob Organizer",        "bob@ems.local",           "Organizer@123", UserRole.Organizer);
        var attendee1  = MakeUser("Charlie Attendee",     "charlie@ems.local",       "Attendee@123",  UserRole.Attendee);
        var attendee2  = MakeUser("Diana Attendee",       "diana@ems.local",         "Attendee@123",  UserRole.Attendee);
        var attendee3  = MakeUser("Eve Attendee",         "eve@ems.local",           "Attendee@123",  UserRole.Attendee);

        dbContext.Users.AddRange(admin, organizer1, organizer2, attendee1, attendee2, attendee3);
        await dbContext.SaveChangesAsync();

        // Events
        var now = DateTime.UtcNow;
        Event MakeEvent(string title, string description, string location, DateTime start, DateTime end, int capacity, decimal priceInRupees, User organizer)
            => new() { Title = title, Description = description, Location = location, StartDateUtc = start, EndDateUtc = end, Capacity = capacity, PriceInRupees = priceInRupees, OrganizerId = organizer.Id };

        var events = new[]
        {
            MakeEvent("Tech Summit 2026",
                "A full-day conference covering the latest in cloud, AI, and DevOps.",
                "Convention Centre, Kuala Lumpur",
                now.AddDays(10), now.AddDays(10).AddHours(8), 200, 4999, organizer1),

            MakeEvent("Web Development Bootcamp",
                "Intensive 2-day hands-on bootcamp on Angular, React and modern tooling.",
                "TechHub, Bangsar South",
                now.AddDays(15), now.AddDays(17).AddHours(6), 50, 2999, organizer1),

            MakeEvent("Startup Pitch Night",
                "An evening where early-stage startups pitch to a panel of investors.",
                "Co-Working Space, KLCC",
                now.AddDays(5), now.AddDays(5).AddHours(3), 80, 0, organizer2),

            MakeEvent("UI/UX Design Workshop",
                "Learn design thinking, Figma, and prototyping techniques from industry experts.",
                "Creative Studio, Mont Kiara",
                now.AddDays(20), now.AddDays(20).AddHours(5), 30, 1999, organizer2),

            MakeEvent("Leadership & Management Seminar",
                "A half-day seminar on agile leadership, team motivation and conflict resolution.",
                "Grand Ballroom, Petaling Jaya",
                now.AddDays(7), now.AddDays(7).AddHours(4), 120, 1499, organizer1),

            MakeEvent("Legacy Tech Meetup",
                "Past meetup for historical organizer dashboard entries.",
                "Hall A, Old Campus",
                now.AddDays(-20), now.AddDays(-20).AddHours(4), 60, 999, organizer2),
        };

        dbContext.Events.AddRange(events);
        await dbContext.SaveChangesAsync();

        // Bookings
        Booking MakeBooking(User attendee, Event ev, bool checkedIn = false)
        {
            var ticket = $"TCK-{DateTime.UtcNow:yyyyMMdd}-{Guid.NewGuid():N}"[..26].ToUpperInvariant();
            return new Booking
            {
                AttendeeId    = attendee.Id,
                EventId       = ev.Id,
                TicketNumber  = ticket,
                Status        = BookingStatus.Booked,
                CheckedInAtUtc = checkedIn ? DateTime.UtcNow.AddMinutes(-30) : null
            };
        }

        dbContext.Bookings.AddRange(
            MakeBooking(attendee1, events[0]),
            MakeBooking(attendee2, events[0], checkedIn: true),
            MakeBooking(attendee3, events[0]),
            MakeBooking(attendee1, events[1]),
            MakeBooking(attendee2, events[2], checkedIn: true),
            MakeBooking(attendee3, events[2]),
            MakeBooking(attendee1, events[4]),
            MakeBooking(attendee3, events[4]),
            MakeBooking(attendee2, events[5], checkedIn: true)
        );

        await dbContext.SaveChangesAsync();
        logger.LogInformation("Seeded sample data: 6 users, {EventCount} events, 8 bookings.", events.Length);
    }

    private static async Task<bool> SqliteColumnExistsAsync(ApplicationDbContext dbContext, string tableName, string columnName)
    {
        await using var connection = new SqliteConnection(dbContext.Database.GetConnectionString());
        await connection.OpenAsync();

        await using var command = connection.CreateCommand();
        command.CommandText = $"PRAGMA table_info({tableName});";
        await using var reader = await command.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            var currentColumnName = reader.GetString(1);
            if (string.Equals(currentColumnName, columnName, StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }
        }

        return false;
    }
}
