using EventManagementSystem.Application.DTOs.Events;

namespace EventManagementSystem.Application.Interfaces.Services;

public interface IEventService
{
    Task<EventResponseDto> CreateAsync(Guid organizerId, CreateEventRequestDto request, CancellationToken cancellationToken = default);
    Task<EventResponseDto> UpdateAsync(Guid requesterId, bool isAdmin, Guid eventId, UpdateEventRequestDto request, CancellationToken cancellationToken = default);
    Task DeleteAsync(Guid requesterId, bool isAdmin, Guid eventId, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<EventResponseDto>> SearchAsync(string? query, bool includePastEvents, CancellationToken cancellationToken = default);
    Task<OrganizerEventsDashboardDto> GetOrganizerDashboardAsync(Guid organizerId, CancellationToken cancellationToken = default);
}
