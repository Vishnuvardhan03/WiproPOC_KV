using EventManagementSystem.Application.DTOs.Notifications;

namespace EventManagementSystem.Application.Interfaces.Services;

public interface INotificationService
{
    Task NotifyUserAsync(Guid userId, string title, string message, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<NotificationDto>> GetMyNotificationsAsync(Guid userId, CancellationToken cancellationToken = default);
    Task MarkAsReadAsync(Guid userId, Guid notificationId, CancellationToken cancellationToken = default);
}
