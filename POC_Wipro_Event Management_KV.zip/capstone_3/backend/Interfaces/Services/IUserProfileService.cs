using EventManagementSystem.Application.DTOs.Users;

namespace EventManagementSystem.Application.Interfaces.Services;

public interface IUserProfileService
{
    Task<UserProfileDto> GetAsync(Guid userId, CancellationToken cancellationToken = default);
    Task<UserProfileDto> UpdateAsync(Guid userId, UpdateProfileRequestDto request, CancellationToken cancellationToken = default);
    Task RequestRoleChangeAsync(Guid userId, RequestRoleChangeDto request, CancellationToken cancellationToken = default);
}
