using EventManagementSystem.Application.DTOs.Payments;

namespace EventManagementSystem.Application.Interfaces.Services;

public interface IPaymentService
{
    Task<PaymentResponseDto> CreatePaymentOrderAsync(Guid attendeeId, CreatePaymentRequestDto request, CancellationToken cancellationToken = default);
    Task<PaymentResponseDto> CompletePaymentAsync(Guid attendeeId, CompletePaymentRequestDto request, CancellationToken cancellationToken = default);
}
