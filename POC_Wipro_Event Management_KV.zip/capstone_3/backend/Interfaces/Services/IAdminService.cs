using EventManagementSystem.Application.DTOs.Admin;
using EventManagementSystem.Application.DTOs.Bookings;

namespace EventManagementSystem.Application.Interfaces.Services;

public interface IAdminService
{
    Task<IReadOnlyList<UserSummaryDto>> GetUsersAsync(CancellationToken cancellationToken = default);
    Task UpdateUserRoleAsync(Guid userId, string role, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<BookingResponseDto>> GetBookingsAsync(CancellationToken cancellationToken = default);
    Task ApproveBookingAsync(Guid bookingId, CancellationToken cancellationToken = default);
    Task DeclineBookingAsync(Guid bookingId, CancellationToken cancellationToken = default);
    Task CancelBookingAsync(Guid bookingId, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<BookingResponseDto>> GetBookingsByEventAsync(Guid eventId, CancellationToken cancellationToken = default);

    Task<IReadOnlyList<RoleChangeRequestDto>> GetPendingRoleRequestsAsync(CancellationToken cancellationToken = default);
    Task ApproveRoleRequestAsync(Guid requestId, Guid adminUserId, string? comment, CancellationToken cancellationToken = default);
    Task RejectRoleRequestAsync(Guid requestId, Guid adminUserId, string? comment, CancellationToken cancellationToken = default);

    Task<IReadOnlyList<EventChangeRequestDto>> GetPendingEventChangeRequestsAsync(CancellationToken cancellationToken = default);
    Task ApproveEventChangeRequestAsync(Guid requestId, Guid adminUserId, string? comment, CancellationToken cancellationToken = default);
    Task RejectEventChangeRequestAsync(Guid requestId, Guid adminUserId, string? comment, CancellationToken cancellationToken = default);

    Task<IReadOnlyList<ActivityLogDto>> GetActivityLogsAsync(int count, CancellationToken cancellationToken = default);
    Task<ReportSummaryDto> GetReportAsync(CancellationToken cancellationToken = default);
}
