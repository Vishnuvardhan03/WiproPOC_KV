using EventManagementSystem.Application.DTOs.Bookings;

namespace EventManagementSystem.Application.Interfaces.Services;

public interface IBookingService
{
    Task<BookingResponseDto> BookAsync(Guid attendeeId, BookEventRequestDto request, CancellationToken cancellationToken = default);
    Task CancelAsync(Guid attendeeId, Guid bookingId, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<BookingResponseDto>> HistoryAsync(Guid attendeeId, CancellationToken cancellationToken = default);
    Task<BookingResponseDto> CheckInAsync(string ticketNumber, CancellationToken cancellationToken = default);
}
