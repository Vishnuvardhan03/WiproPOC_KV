namespace EventManagementSystem.Application.Interfaces.Services;

public interface IActivityLogService
{
    Task LogAsync(Guid? actorUserId, string action, string entityType, Guid? entityId, string metadata, CancellationToken cancellationToken = default);
}
