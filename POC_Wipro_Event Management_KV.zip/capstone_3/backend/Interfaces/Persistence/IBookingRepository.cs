using EventManagementSystem.Domain.Entities;

namespace EventManagementSystem.Application.Interfaces.Persistence;

public interface IBookingRepository
{
    Task<Booking?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default);
    Task<Booking?> GetByEventAndAttendeeAsync(Guid eventId, Guid attendeeId, CancellationToken cancellationToken = default);
    Task<Booking?> GetByTicketNumberAsync(string ticketNumber, CancellationToken cancellationToken = default);
    Task<int> CountActiveBookingsByEventIdAsync(Guid eventId, CancellationToken cancellationToken = default);
    Task<Dictionary<Guid, int>> GetActiveBookingCountsByEventIdsAsync(IEnumerable<Guid> eventIds, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<Booking>> GetByEventIdAsync(Guid eventId, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<Booking>> GetByAttendeeIdAsync(Guid attendeeId, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<Booking>> GetAllAsync(CancellationToken cancellationToken = default);
    Task<bool> TicketNumberExistsAsync(string ticketNumber, CancellationToken cancellationToken = default);
    Task<int> CountAllAsync(CancellationToken cancellationToken = default);
    Task<int> CountApprovedAsync(CancellationToken cancellationToken = default);
    Task<int> CountCancelledAsync(CancellationToken cancellationToken = default);
    Task<int> CountCheckedInAsync(CancellationToken cancellationToken = default);
    Task AddAsync(Booking booking, CancellationToken cancellationToken = default);
    Task SaveChangesAsync(CancellationToken cancellationToken = default);
}
