using EventManagementSystem.Domain.Entities;

namespace EventManagementSystem.Application.Interfaces.Persistence;

public interface IEventChangeRequestRepository
{
    Task<EventChangeRequest?> GetByIdAsync(Guid requestId, CancellationToken cancellationToken = default);
    Task<EventChangeRequest?> GetPendingByEventIdAsync(Guid eventId, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<EventChangeRequest>> GetPendingAsync(CancellationToken cancellationToken = default);
    Task AddAsync(EventChangeRequest request, CancellationToken cancellationToken = default);
    Task SaveChangesAsync(CancellationToken cancellationToken = default);
}
