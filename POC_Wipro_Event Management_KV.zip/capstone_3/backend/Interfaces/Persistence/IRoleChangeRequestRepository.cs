using EventManagementSystem.Domain.Entities;

namespace EventManagementSystem.Application.Interfaces.Persistence;

public interface IRoleChangeRequestRepository
{
    Task<RoleChangeRequest?> GetByIdAsync(Guid requestId, CancellationToken cancellationToken = default);
    Task<RoleChangeRequest?> GetPendingByUserIdAsync(Guid userId, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<RoleChangeRequest>> GetPendingAsync(CancellationToken cancellationToken = default);
    Task AddAsync(RoleChangeRequest request, CancellationToken cancellationToken = default);
    Task SaveChangesAsync(CancellationToken cancellationToken = default);
}
