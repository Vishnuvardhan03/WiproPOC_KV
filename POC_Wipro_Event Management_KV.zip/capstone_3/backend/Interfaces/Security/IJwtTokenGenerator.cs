using EventManagementSystem.Domain.Entities;

namespace EventManagementSystem.Application.Interfaces.Security;

public interface IJwtTokenGenerator
{
    (string Token, DateTime ExpiresAtUtc) Generate(User user);
}
