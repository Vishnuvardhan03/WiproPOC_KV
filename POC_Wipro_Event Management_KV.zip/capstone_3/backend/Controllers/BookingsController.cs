using EventManagementSystem.API.Extensions;
using EventManagementSystem.Application.DTOs.Bookings;
using EventManagementSystem.Application.Interfaces.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EventManagementSystem.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class BookingsController : ControllerBase
{
    private readonly IBookingService _bookingService;

    public BookingsController(IBookingService bookingService)
    {
        _bookingService = bookingService;
    }

    [HttpPost]
    [Authorize(Roles = "Attendee")]
    public async Task<ActionResult<BookingResponseDto>> Book([FromBody] BookEventRequestDto request, CancellationToken cancellationToken)
    {
        var attendeeId = User.GetUserId();
        var response = await _bookingService.BookAsync(attendeeId, request, cancellationToken);
        return Ok(response);
    }

    [HttpDelete("{bookingId:guid}")]
    [Authorize(Roles = "Attendee")]
    public async Task<IActionResult> Cancel(Guid bookingId, CancellationToken cancellationToken)
    {
        var attendeeId = User.GetUserId();
        await _bookingService.CancelAsync(attendeeId, bookingId, cancellationToken);
        return NoContent();
    }

    [HttpGet]
    [Authorize]
    public async Task<ActionResult<IReadOnlyList<BookingResponseDto>>> GetBookings(CancellationToken cancellationToken)
    {
        var attendeeId = User.GetUserId();
        var history = await _bookingService.HistoryAsync(attendeeId, cancellationToken);
        return Ok(history);
    }

    [HttpGet("history")]
    [Authorize]
    public async Task<ActionResult<IReadOnlyList<BookingResponseDto>>> History(CancellationToken cancellationToken)
    {
        var attendeeId = User.GetUserId();
        var history = await _bookingService.HistoryAsync(attendeeId, cancellationToken);
        return Ok(history);
    }

    [HttpPost("check-in")]
    [Authorize(Roles = "Organizer,Admin")]
    public async Task<ActionResult<BookingResponseDto>> CheckIn([FromBody] CheckInRequestDto request, CancellationToken cancellationToken)
    {
        var booking = await _bookingService.CheckInAsync(request.TicketNumber, cancellationToken);
        return Ok(booking);
    }
}
