using EventManagementSystem.Application.DTOs.Auth;
using EventManagementSystem.Application.Interfaces.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace EventManagementSystem.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly IAuthService _authService;
    private readonly ILogger<AuthController> _logger;

    public AuthController(IAuthService authService, ILogger<AuthController> logger)
    {
        _authService = authService;
        _logger = logger;
    }

    [HttpPost("register")]
    [AllowAnonymous]
    public async Task<ActionResult<AuthResponseDto>> Register([FromBody] RegisterRequestDto request, CancellationToken cancellationToken)
    {
        var response = await _authService.RegisterAsync(request, cancellationToken);
        return Ok(response);
    }

    [HttpPost("login")]
    [AllowAnonymous]
    public async Task<ActionResult<AuthResponseDto>> Login([FromBody] LoginRequestDto request, CancellationToken cancellationToken)
    {
        var stopwatch = Stopwatch.StartNew();
        try
        {
            var response = await _authService.LoginAsync(request, cancellationToken);
            stopwatch.Stop();
            _logger.LogInformation("LOGIN RESPONSE email={Email} status=200 durationMs={DurationMs} role={Role}", request.Email, stopwatch.ElapsedMilliseconds, response.Role);
            return Ok(response);
        }
        catch (UnauthorizedAccessException)
        {
            stopwatch.Stop();
            _logger.LogWarning("LOGIN RESPONSE email={Email} status=401 durationMs={DurationMs}", request.Email, stopwatch.ElapsedMilliseconds);
            return Unauthorized(new { error = "Invalid credentials." });
        }
    }
}
