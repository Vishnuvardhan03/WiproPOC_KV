using EventManagementSystem.API.Extensions;
using EventManagementSystem.Application.DTOs.Users;
using EventManagementSystem.Application.Interfaces.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EventManagementSystem.API.Controllers;

[ApiController]
[Route("api/profile")]
[Authorize]
public class ProfileController : ControllerBase
{
    private readonly IUserProfileService _profileService;

    public ProfileController(IUserProfileService profileService)
    {
        _profileService = profileService;
    }

    [HttpGet]
    public async Task<ActionResult<UserProfileDto>> Get(CancellationToken cancellationToken)
    {
        var profile = await _profileService.GetAsync(User.GetUserId(), cancellationToken);
        return Ok(profile);
    }

    [HttpPut]
    public async Task<ActionResult<UserProfileDto>> Update([FromBody] UpdateProfileRequestDto request, CancellationToken cancellationToken)
    {
        var profile = await _profileService.UpdateAsync(User.GetUserId(), request, cancellationToken);
        return Ok(profile);
    }

    [HttpPost("role-request")]
    public async Task<IActionResult> RequestRoleChange([FromBody] RequestRoleChangeDto request, CancellationToken cancellationToken)
    {
        await _profileService.RequestRoleChangeAsync(User.GetUserId(), request, cancellationToken);
        return Accepted();
    }
}
