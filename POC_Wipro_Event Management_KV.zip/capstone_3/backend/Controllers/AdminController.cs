using EventManagementSystem.Application.DTOs.Admin;
using EventManagementSystem.Application.DTOs.Bookings;
using EventManagementSystem.Application.DTOs.Events;
using EventManagementSystem.Application.Interfaces.Services;
using EventManagementSystem.API.Extensions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EventManagementSystem.API.Controllers;

[ApiController]
[Route("api/admin")]
[Authorize(Roles = "Admin")]
public class AdminController : ControllerBase
{
    private readonly IAdminService _adminService;
    private readonly IEventService _eventService;

    public AdminController(IAdminService adminService, IEventService eventService)
    {
        _adminService = adminService;
        _eventService = eventService;
    }

    [HttpGet("users")]
    public async Task<ActionResult<IReadOnlyList<UserSummaryDto>>> GetUsers(CancellationToken cancellationToken)
    {
        var users = await _adminService.GetUsersAsync(cancellationToken);
        return Ok(users);
    }

    [HttpPatch("users/{userId:guid}/role")]
    public async Task<IActionResult> UpdateUserRole(Guid userId, [FromBody] UpdateUserRoleRequestDto request, CancellationToken cancellationToken)
    {
        await _adminService.UpdateUserRoleAsync(userId, request.Role, cancellationToken);
        return NoContent();
    }

    [HttpGet("events")]
    public async Task<ActionResult<IReadOnlyList<EventResponseDto>>> GetEvents(CancellationToken cancellationToken)
    {
        var events = await _eventService.SearchAsync(null, includePastEvents: true, cancellationToken);
        return Ok(events);
    }

    [HttpGet("events/{eventId:guid}/bookings")]
    public async Task<ActionResult<IReadOnlyList<BookingResponseDto>>> GetEventBookings(Guid eventId, CancellationToken cancellationToken)
    {
        var bookings = await _adminService.GetBookingsByEventAsync(eventId, cancellationToken);
        return Ok(bookings);
    }

    [HttpDelete("events/{eventId:guid}")]
    public async Task<IActionResult> DeleteEvent(Guid eventId, CancellationToken cancellationToken)
    {
        await _eventService.DeleteAsync(Guid.Empty, true, eventId, cancellationToken);
        return NoContent();
    }

    [HttpGet("bookings")]
    public async Task<ActionResult<IReadOnlyList<BookingResponseDto>>> GetBookings(CancellationToken cancellationToken)
    {
        var bookings = await _adminService.GetBookingsAsync(cancellationToken);
        return Ok(bookings);
    }

    [HttpPatch("bookings/{bookingId:guid}/approve")]
    public async Task<IActionResult> ApproveBooking(Guid bookingId, CancellationToken cancellationToken)
    {
        await _adminService.ApproveBookingAsync(bookingId, cancellationToken);
        return NoContent();
    }

    [HttpPatch("bookings/{bookingId:guid}/decline")]
    public async Task<IActionResult> DeclineBooking(Guid bookingId, CancellationToken cancellationToken)
    {
        await _adminService.DeclineBookingAsync(bookingId, cancellationToken);
        return NoContent();
    }

    [HttpDelete("bookings/{bookingId:guid}")]
    public async Task<IActionResult> CancelBooking(Guid bookingId, CancellationToken cancellationToken)
    {
        await _adminService.CancelBookingAsync(bookingId, cancellationToken);
        return NoContent();
    }

    [HttpGet("reports")]
    public async Task<ActionResult<ReportSummaryDto>> Reports(CancellationToken cancellationToken)
    {
        var report = await _adminService.GetReportAsync(cancellationToken);
        return Ok(report);
    }

    [HttpGet("role-requests")]
    public async Task<ActionResult<IReadOnlyList<RoleChangeRequestDto>>> GetPendingRoleRequests(CancellationToken cancellationToken)
    {
        var requests = await _adminService.GetPendingRoleRequestsAsync(cancellationToken);
        return Ok(requests);
    }

    [HttpPatch("role-requests/{requestId:guid}/approve")]
    public async Task<IActionResult> ApproveRoleRequest(Guid requestId, [FromBody] RoleChangeRequestReviewDto request, CancellationToken cancellationToken)
    {
        await _adminService.ApproveRoleRequestAsync(requestId, User.GetUserId(), request.Comment, cancellationToken);
        return NoContent();
    }

    [HttpPatch("role-requests/{requestId:guid}/reject")]
    public async Task<IActionResult> RejectRoleRequest(Guid requestId, [FromBody] RoleChangeRequestReviewDto request, CancellationToken cancellationToken)
    {
        await _adminService.RejectRoleRequestAsync(requestId, User.GetUserId(), request.Comment, cancellationToken);
        return NoContent();
    }

    [HttpGet("event-change-requests")]
    public async Task<ActionResult<IReadOnlyList<EventChangeRequestDto>>> GetPendingEventChangeRequests(CancellationToken cancellationToken)
    {
        var requests = await _adminService.GetPendingEventChangeRequestsAsync(cancellationToken);
        return Ok(requests);
    }

    [HttpPatch("event-change-requests/{requestId:guid}/approve")]
    public async Task<IActionResult> ApproveEventChangeRequest(Guid requestId, [FromBody] EventChangeRequestReviewDto request, CancellationToken cancellationToken)
    {
        await _adminService.ApproveEventChangeRequestAsync(requestId, User.GetUserId(), request.Comment, cancellationToken);
        return NoContent();
    }

    [HttpPatch("event-change-requests/{requestId:guid}/reject")]
    public async Task<IActionResult> RejectEventChangeRequest(Guid requestId, [FromBody] EventChangeRequestReviewDto request, CancellationToken cancellationToken)
    {
        await _adminService.RejectEventChangeRequestAsync(requestId, User.GetUserId(), request.Comment, cancellationToken);
        return NoContent();
    }

    [HttpGet("activity-logs")]
    public async Task<ActionResult<IReadOnlyList<ActivityLogDto>>> GetActivityLogs([FromQuery] int count = 100, CancellationToken cancellationToken = default)
    {
        var logs = await _adminService.GetActivityLogsAsync(count, cancellationToken);
        return Ok(logs);
    }
}
