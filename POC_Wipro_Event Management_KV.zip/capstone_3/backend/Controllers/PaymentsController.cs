using EventManagementSystem.API.Extensions;
using EventManagementSystem.Application.DTOs.Payments;
using EventManagementSystem.Application.Interfaces.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EventManagementSystem.API.Controllers;

[ApiController]
[Route("api/payments")]
[Authorize(Roles = "Attendee")]
public class PaymentsController : ControllerBase
{
    private readonly IPaymentService _paymentService;

    public PaymentsController(IPaymentService paymentService)
    {
        _paymentService = paymentService;
    }

    [HttpPost("order")]
    public async Task<ActionResult<PaymentResponseDto>> CreateOrder([FromBody] CreatePaymentRequestDto request, CancellationToken cancellationToken)
    {
        var response = await _paymentService.CreatePaymentOrderAsync(User.GetUserId(), request, cancellationToken);
        return Ok(response);
    }

    [HttpPost("complete")]
    public async Task<ActionResult<PaymentResponseDto>> Complete([FromBody] CompletePaymentRequestDto request, CancellationToken cancellationToken)
    {
        var response = await _paymentService.CompletePaymentAsync(User.GetUserId(), request, cancellationToken);
        return Ok(response);
    }
}
