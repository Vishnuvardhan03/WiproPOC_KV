using EventManagementSystem.API.Extensions;
using EventManagementSystem.Application.DTOs.Events;
using EventManagementSystem.Application.Interfaces.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EventManagementSystem.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class EventsController : ControllerBase
{
    private readonly IEventService _eventService;

    public EventsController(IEventService eventService)
    {
        _eventService = eventService;
    }

    [HttpGet]
    [AllowAnonymous]
    public async Task<ActionResult<IReadOnlyList<EventResponseDto>>> GetAll(CancellationToken cancellationToken)
    {
        var events = await _eventService.SearchAsync(null, includePastEvents: false, cancellationToken);
        return Ok(events);
    }

    [HttpGet("search")]
    [AllowAnonymous]
    public async Task<ActionResult<IReadOnlyList<EventResponseDto>>> Search([FromQuery] string? query, CancellationToken cancellationToken)
    {
        var events = await _eventService.SearchAsync(query, includePastEvents: false, cancellationToken);
        return Ok(events);
    }

    [HttpGet("organizer/dashboard")]
    [Authorize(Roles = "Organizer,Admin")]
    public async Task<ActionResult<OrganizerEventsDashboardDto>> OrganizerDashboard(CancellationToken cancellationToken)
    {
        var organizerId = User.GetUserId();
        var dashboard = await _eventService.GetOrganizerDashboardAsync(organizerId, cancellationToken);
        return Ok(dashboard);
    }

    [HttpPost]
    [Authorize(Roles = "Organizer,Admin")]
    public async Task<ActionResult<EventResponseDto>> Create([FromBody] CreateEventRequestDto request, CancellationToken cancellationToken)
    {
        var organizerId = User.GetUserId();
        var created = await _eventService.CreateAsync(organizerId, request, cancellationToken);
        return Ok(created);
    }

    [HttpPut("{eventId:guid}")]
    [Authorize(Roles = "Organizer,Admin")]
    public async Task<ActionResult<EventResponseDto>> Update(Guid eventId, [FromBody] UpdateEventRequestDto request, CancellationToken cancellationToken)
    {
        var requesterId = User.GetUserId();
        var updated = await _eventService.UpdateAsync(requesterId, User.IsInRole("Admin"), eventId, request, cancellationToken);
        return Ok(updated);
    }

    [HttpDelete("{eventId:guid}")]
    [Authorize(Roles = "Organizer,Admin")]
    public async Task<IActionResult> Delete(Guid eventId, CancellationToken cancellationToken)
    {
        var requesterId = User.GetUserId();
        await _eventService.DeleteAsync(requesterId, User.IsInRole("Admin"), eventId, cancellationToken);
        return NoContent();
    }
}
