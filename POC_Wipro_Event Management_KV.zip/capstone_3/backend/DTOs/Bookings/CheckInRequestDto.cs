using System.ComponentModel.DataAnnotations;

namespace EventManagementSystem.Application.DTOs.Bookings;

public class CheckInRequestDto
{
    [Required]
    [StringLength(40, MinimumLength = 10)]
    public string TicketNumber { get; set; } = string.Empty;
}
