using System.ComponentModel.DataAnnotations;

namespace EventManagementSystem.Application.DTOs.Bookings;

public class BookEventRequestDto
{
    [Required]
    public Guid EventId { get; set; }
}
