namespace EventManagementSystem.Application.DTOs.Bookings;

public class BookingResponseDto
{
    public Guid BookingId { get; set; }
    public Guid EventId { get; set; }
    public Guid AttendeeId { get; set; }
    public string AttendeeName { get; set; } = string.Empty;
    public string AttendeeEmail { get; set; } = string.Empty;
    public string EventTitle { get; set; } = string.Empty;
    public DateTime EventStartDateUtc { get; set; }
    public DateTime EventEndDateUtc { get; set; }
    public string TicketNumber { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public DateTime CreatedAtUtc { get; set; }
    public DateTime? CheckedInAtUtc { get; set; }
}
