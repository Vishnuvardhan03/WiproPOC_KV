namespace EventManagementSystem.Application.DTOs.Admin;

public class ActivityLogDto
{
    public Guid Id { get; set; }
    public Guid? ActorUserId { get; set; }
    public string ActorUserName { get; set; } = string.Empty;
    public string Action { get; set; } = string.Empty;
    public string EntityType { get; set; } = string.Empty;
    public Guid? EntityId { get; set; }
    public string Metadata { get; set; } = string.Empty;
    public DateTime CreatedAtUtc { get; set; }
}
