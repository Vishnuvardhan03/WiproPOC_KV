namespace EventManagementSystem.Application.DTOs.Admin;

public class RoleChangeRequestDto
{
    public Guid RequestId { get; set; }
    public Guid UserId { get; set; }
    public string UserName { get; set; } = string.Empty;
    public string UserEmail { get; set; } = string.Empty;
    public string CurrentRole { get; set; } = string.Empty;
    public string RequestedRole { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public string? AdminComment { get; set; }
    public DateTime CreatedAtUtc { get; set; }
}
