using System.ComponentModel.DataAnnotations;

namespace EventManagementSystem.Application.DTOs.Admin;

public class EventChangeRequestReviewDto
{
    [StringLength(1000)]
    public string? Comment { get; set; }
}
