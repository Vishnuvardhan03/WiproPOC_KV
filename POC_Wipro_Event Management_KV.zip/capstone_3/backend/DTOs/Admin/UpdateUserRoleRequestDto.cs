using System.ComponentModel.DataAnnotations;

namespace EventManagementSystem.Application.DTOs.Admin;

public class UpdateUserRoleRequestDto
{
    [Required]
    [StringLength(30, MinimumLength = 4)]
    public string Role { get; set; } = string.Empty;
}
