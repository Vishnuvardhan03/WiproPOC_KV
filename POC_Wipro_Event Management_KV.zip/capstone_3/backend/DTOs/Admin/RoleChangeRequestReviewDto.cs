using System.ComponentModel.DataAnnotations;

namespace EventManagementSystem.Application.DTOs.Admin;

public class RoleChangeRequestReviewDto
{
    [StringLength(1000)]
    public string? Comment { get; set; }
}
