namespace EventManagementSystem.Application.DTOs.Admin;

public class ReportSummaryDto
{
    public int TotalUsers { get; set; }
    public int TotalAdmins { get; set; }
    public int TotalOrganizers { get; set; }
    public int TotalAttendees { get; set; }
    public int TotalEvents { get; set; }
    public int UpcomingEvents { get; set; }
    public int CompletedEvents { get; set; }
    public int TotalBookings { get; set; }
    public int CancelledBookings { get; set; }
    public int CheckedInAttendees { get; set; }
    public int ActiveEvents { get; set; }
    public int TotalCapacity { get; set; }
    public decimal OccupancyPercentage { get; set; }
}
