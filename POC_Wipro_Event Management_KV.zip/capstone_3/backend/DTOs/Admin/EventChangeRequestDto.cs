namespace EventManagementSystem.Application.DTOs.Admin;

public class EventChangeRequestDto
{
    public Guid RequestId { get; set; }
    public Guid EventId { get; set; }
    public string EventTitle { get; set; } = string.Empty;
    public Guid RequestedByOrganizerId { get; set; }
    public string RequestedByOrganizerName { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public string? AdminComment { get; set; }
    public DateTime CreatedAtUtc { get; set; }

    public string ProposedTitle { get; set; } = string.Empty;
    public string ProposedDescription { get; set; } = string.Empty;
    public string ProposedLocation { get; set; } = string.Empty;
    public DateTime ProposedStartDateUtc { get; set; }
    public DateTime ProposedEndDateUtc { get; set; }
    public int ProposedCapacity { get; set; }
    public decimal ProposedPriceInRupees { get; set; }
}
