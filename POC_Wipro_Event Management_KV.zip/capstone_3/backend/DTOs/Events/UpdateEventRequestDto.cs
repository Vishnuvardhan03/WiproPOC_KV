using System.ComponentModel.DataAnnotations;

namespace EventManagementSystem.Application.DTOs.Events;

public class UpdateEventRequestDto
{
    [Required]
    [StringLength(200, MinimumLength = 3)]
    public string Title { get; set; } = string.Empty;

    [Required]
    [StringLength(2000, MinimumLength = 10)]
    public string Description { get; set; } = string.Empty;

    [Required]
    [StringLength(200, MinimumLength = 2)]
    public string Location { get; set; } = string.Empty;

    [Required]
    public DateTime StartDateUtc { get; set; }

    [Required]
    public DateTime EndDateUtc { get; set; }

    [Range(1, 200000)]
    public int Capacity { get; set; }

    [Range(0, 100000000)]
    public decimal PriceInRupees { get; set; }
}
