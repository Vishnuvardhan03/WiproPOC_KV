namespace EventManagementSystem.Application.DTOs.Events;

public class EventAttendeeDto
{
    public Guid AttendeeId { get; set; }
    public string FullName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string BookingStatus { get; set; } = string.Empty;
    public string TicketNumber { get; set; } = string.Empty;
    public DateTime? CheckedInAtUtc { get; set; }
}
