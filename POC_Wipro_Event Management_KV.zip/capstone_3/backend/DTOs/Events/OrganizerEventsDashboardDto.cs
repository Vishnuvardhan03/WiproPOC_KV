namespace EventManagementSystem.Application.DTOs.Events;

public class OrganizerEventsDashboardDto
{
    public IReadOnlyList<OrganizerEventWithAttendeesDto> UpcomingEvents { get; set; } = [];
    public IReadOnlyList<OrganizerEventWithAttendeesDto> PastEvents { get; set; } = [];
}
