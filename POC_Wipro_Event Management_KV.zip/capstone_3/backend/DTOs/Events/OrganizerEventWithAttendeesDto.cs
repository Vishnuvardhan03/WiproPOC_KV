namespace EventManagementSystem.Application.DTOs.Events;

public class OrganizerEventWithAttendeesDto
{
    public Guid EventId { get; set; }
    public string Title { get; set; } = string.Empty;
    public string Location { get; set; } = string.Empty;
    public DateTime StartDateUtc { get; set; }
    public DateTime EndDateUtc { get; set; }
    public int Capacity { get; set; }
    public decimal PriceInRupees { get; set; }
    public IReadOnlyList<EventAttendeeDto> Attendees { get; set; } = [];
}
