using System.ComponentModel.DataAnnotations;

namespace EventManagementSystem.Application.DTOs.Users;

public class RequestRoleChangeDto
{
    [Required]
    [StringLength(30, MinimumLength = 4)]
    public string Role { get; set; } = string.Empty;
}
