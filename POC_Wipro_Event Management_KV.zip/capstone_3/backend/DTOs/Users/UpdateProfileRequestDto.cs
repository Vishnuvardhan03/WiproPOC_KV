using System.ComponentModel.DataAnnotations;

namespace EventManagementSystem.Application.DTOs.Users;

public class UpdateProfileRequestDto
{
    [Required]
    [StringLength(150, MinimumLength = 2)]
    public string FullName { get; set; } = string.Empty;
}
