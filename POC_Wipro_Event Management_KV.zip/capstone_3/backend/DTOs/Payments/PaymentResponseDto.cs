namespace EventManagementSystem.Application.DTOs.Payments;

public class PaymentResponseDto
{
    public Guid PaymentId { get; set; }
    public Guid BookingId { get; set; }
    public decimal AmountInRupees { get; set; }
    public string Currency { get; set; } = "INR";
    public string ProviderOrderId { get; set; } = string.Empty;
    public string ProviderPaymentId { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public DateTime CreatedAtUtc { get; set; }
    public DateTime? PaidAtUtc { get; set; }
}
