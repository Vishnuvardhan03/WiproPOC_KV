using System.ComponentModel.DataAnnotations;

namespace EventManagementSystem.Application.DTOs.Payments;

public class CreatePaymentRequestDto
{
    [Required]
    public Guid BookingId { get; set; }
}
