using System.ComponentModel.DataAnnotations;

namespace EventManagementSystem.Application.DTOs.Payments;

public class CompletePaymentRequestDto
{
    [Required]
    [StringLength(120)]
    public string ProviderOrderId { get; set; } = string.Empty;

    [Required]
    [StringLength(120)]
    public string ProviderPaymentId { get; set; } = string.Empty;

    public bool Success { get; set; }

    [StringLength(1000)]
    public string? FailureReason { get; set; }
}
