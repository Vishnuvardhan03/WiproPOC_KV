using EventManagementSystem.Application.Interfaces.Persistence;
using EventManagementSystem.Domain.Entities;
using EventManagementSystem.Domain.Enums;
using Microsoft.EntityFrameworkCore;

namespace EventManagementSystem.Infrastructure.Persistence.Repositories;

public class RoleChangeRequestRepository : IRoleChangeRequestRepository
{
    private readonly ApplicationDbContext _dbContext;

    public RoleChangeRequestRepository(ApplicationDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public Task<RoleChangeRequest?> GetByIdAsync(Guid requestId, CancellationToken cancellationToken = default)
    {
        return _dbContext.RoleChangeRequests
            .Include(x => x.User)
            .FirstOrDefaultAsync(x => x.Id == requestId, cancellationToken);
    }

    public Task<RoleChangeRequest?> GetPendingByUserIdAsync(Guid userId, CancellationToken cancellationToken = default)
    {
        return _dbContext.RoleChangeRequests
            .FirstOrDefaultAsync(x => x.UserId == userId && x.Status == RoleRequestStatus.Pending, cancellationToken);
    }

    public async Task<IReadOnlyList<RoleChangeRequest>> GetPendingAsync(CancellationToken cancellationToken = default)
    {
        return await _dbContext.RoleChangeRequests
            .Include(x => x.User)
            .Where(x => x.Status == RoleRequestStatus.Pending)
            .OrderBy(x => x.CreatedAtUtc)
            .ToListAsync(cancellationToken);
    }

    public async Task AddAsync(RoleChangeRequest request, CancellationToken cancellationToken = default)
    {
        await _dbContext.RoleChangeRequests.AddAsync(request, cancellationToken);
    }

    public Task SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        return _dbContext.SaveChangesAsync(cancellationToken);
    }
}
