using EventManagementSystem.Application.Interfaces.Persistence;
using EventManagementSystem.Domain.Entities;
using EventManagementSystem.Domain.Enums;
using Microsoft.EntityFrameworkCore;

namespace EventManagementSystem.Infrastructure.Persistence.Repositories;

public class BookingRepository : IBookingRepository
{
    private readonly ApplicationDbContext _dbContext;

    public BookingRepository(ApplicationDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public Task<Booking?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default)
    {
        return _dbContext.Bookings.Include(x => x.Event).FirstOrDefaultAsync(x => x.Id == id, cancellationToken);
    }

    public Task<Booking?> GetByEventAndAttendeeAsync(Guid eventId, Guid attendeeId, CancellationToken cancellationToken = default)
    {
        return _dbContext.Bookings.FirstOrDefaultAsync(
            x => x.EventId == eventId && x.AttendeeId == attendeeId,
            cancellationToken);
    }

    public Task<Booking?> GetByTicketNumberAsync(string ticketNumber, CancellationToken cancellationToken = default)
    {
        return _dbContext.Bookings
            .Include(x => x.Event)
            .FirstOrDefaultAsync(x => x.TicketNumber == ticketNumber, cancellationToken);
    }

    public Task<int> CountActiveBookingsByEventIdAsync(Guid eventId, CancellationToken cancellationToken = default)
    {
        return _dbContext.Bookings.CountAsync(
            x => x.EventId == eventId && x.Status == BookingStatus.Booked,
            cancellationToken);
    }

    public async Task<Dictionary<Guid, int>> GetActiveBookingCountsByEventIdsAsync(IEnumerable<Guid> eventIds, CancellationToken cancellationToken = default)
    {
        var ids = eventIds.ToList();
        return await _dbContext.Bookings
            .Where(x => ids.Contains(x.EventId) && x.Status == BookingStatus.Booked)
            .GroupBy(x => x.EventId)
            .Select(g => new { EventId = g.Key, Count = g.Count() })
            .ToDictionaryAsync(x => x.EventId, x => x.Count, cancellationToken);
    }

    public async Task<IReadOnlyList<Booking>> GetByEventIdAsync(Guid eventId, CancellationToken cancellationToken = default)
    {
        return await _dbContext.Bookings
            .Include(x => x.Attendee)
            .Include(x => x.Event)
            .Where(x => x.EventId == eventId)
            .OrderByDescending(x => x.CreatedAtUtc)
            .ToListAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<Booking>> GetByAttendeeIdAsync(Guid attendeeId, CancellationToken cancellationToken = default)
    {
        return await _dbContext.Bookings
            .Include(x => x.Event)
            .Include(x => x.Attendee)
            .Where(x => x.AttendeeId == attendeeId)
            .OrderByDescending(x => x.CreatedAtUtc)
            .ToListAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<Booking>> GetAllAsync(CancellationToken cancellationToken = default)
    {
        return await _dbContext.Bookings
            .Include(x => x.Event)
            .Include(x => x.Attendee)
            .OrderByDescending(x => x.CreatedAtUtc)
            .ToListAsync(cancellationToken);
    }

    public Task<bool> TicketNumberExistsAsync(string ticketNumber, CancellationToken cancellationToken = default)
    {
        return _dbContext.Bookings.AnyAsync(x => x.TicketNumber == ticketNumber, cancellationToken);
    }

    public Task<int> CountAllAsync(CancellationToken cancellationToken = default)
    {
        return _dbContext.Bookings.CountAsync(cancellationToken);
    }

    public Task<int> CountApprovedAsync(CancellationToken cancellationToken = default)
    {
        return _dbContext.Bookings.CountAsync(x => x.Status == BookingStatus.Booked, cancellationToken);
    }

    public Task<int> CountCancelledAsync(CancellationToken cancellationToken = default)
    {
        return _dbContext.Bookings.CountAsync(x => x.Status == BookingStatus.Cancelled, cancellationToken);
    }

    public Task<int> CountCheckedInAsync(CancellationToken cancellationToken = default)
    {
        return _dbContext.Bookings.CountAsync(x => x.CheckedInAtUtc != null, cancellationToken);
    }

    public async Task AddAsync(Booking booking, CancellationToken cancellationToken = default)
    {
        await _dbContext.Bookings.AddAsync(booking, cancellationToken);
    }

    public Task SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        return _dbContext.SaveChangesAsync(cancellationToken);
    }
}
