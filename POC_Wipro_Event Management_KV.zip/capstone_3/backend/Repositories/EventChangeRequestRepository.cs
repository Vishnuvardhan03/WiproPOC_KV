using EventManagementSystem.Application.Interfaces.Persistence;
using EventManagementSystem.Domain.Entities;
using EventManagementSystem.Domain.Enums;
using Microsoft.EntityFrameworkCore;

namespace EventManagementSystem.Infrastructure.Persistence.Repositories;

public class EventChangeRequestRepository : IEventChangeRequestRepository
{
    private readonly ApplicationDbContext _dbContext;

    public EventChangeRequestRepository(ApplicationDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public Task<EventChangeRequest?> GetByIdAsync(Guid requestId, CancellationToken cancellationToken = default)
    {
        return _dbContext.EventChangeRequests
            .Include(x => x.Event)
            .Include(x => x.RequestedByOrganizer)
            .FirstOrDefaultAsync(x => x.Id == requestId, cancellationToken);
    }

    public Task<EventChangeRequest?> GetPendingByEventIdAsync(Guid eventId, CancellationToken cancellationToken = default)
    {
        return _dbContext.EventChangeRequests
            .FirstOrDefaultAsync(x => x.EventId == eventId && x.Status == EventChangeRequestStatus.Pending, cancellationToken);
    }

    public async Task<IReadOnlyList<EventChangeRequest>> GetPendingAsync(CancellationToken cancellationToken = default)
    {
        return await _dbContext.EventChangeRequests
            .Include(x => x.Event)
            .Include(x => x.RequestedByOrganizer)
            .Where(x => x.Status == EventChangeRequestStatus.Pending)
            .OrderBy(x => x.CreatedAtUtc)
            .ToListAsync(cancellationToken);
    }

    public async Task AddAsync(EventChangeRequest request, CancellationToken cancellationToken = default)
    {
        await _dbContext.EventChangeRequests.AddAsync(request, cancellationToken);
    }

    public Task SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        return _dbContext.SaveChangesAsync(cancellationToken);
    }
}
