using EventManagementSystem.Application.Interfaces.Persistence;
using EventManagementSystem.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace EventManagementSystem.Infrastructure.Persistence.Repositories;

public class PaymentRepository : IPaymentRepository
{
    private readonly ApplicationDbContext _dbContext;

    public PaymentRepository(ApplicationDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public Task<Payment?> GetByIdAsync(Guid paymentId, CancellationToken cancellationToken = default)
    {
        return _dbContext.Payments
            .Include(x => x.Booking)
                .ThenInclude(x => x.Event)
            .FirstOrDefaultAsync(x => x.Id == paymentId, cancellationToken);
    }

    public Task<Payment?> GetByProviderOrderIdAsync(string providerOrderId, CancellationToken cancellationToken = default)
    {
        return _dbContext.Payments
            .Include(x => x.Booking)
                .ThenInclude(x => x.Event)
            .FirstOrDefaultAsync(x => x.ProviderOrderId == providerOrderId, cancellationToken);
    }

    public Task<Payment?> GetByBookingIdAsync(Guid bookingId, CancellationToken cancellationToken = default)
    {
        return _dbContext.Payments
            .Include(x => x.Booking)
                .ThenInclude(x => x.Event)
            .FirstOrDefaultAsync(x => x.BookingId == bookingId, cancellationToken);
    }

    public async Task AddAsync(Payment payment, CancellationToken cancellationToken = default)
    {
        await _dbContext.Payments.AddAsync(payment, cancellationToken);
    }

    public Task SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        return _dbContext.SaveChangesAsync(cancellationToken);
    }
}
