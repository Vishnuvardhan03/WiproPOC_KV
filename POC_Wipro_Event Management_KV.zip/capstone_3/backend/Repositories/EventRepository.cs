using EventManagementSystem.Application.Interfaces.Persistence;
using EventManagementSystem.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace EventManagementSystem.Infrastructure.Persistence.Repositories;

public class EventRepository : IEventRepository
{
    private readonly ApplicationDbContext _dbContext;

    public EventRepository(ApplicationDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public Task<Event?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default)
    {
        return _dbContext.Events
            .Include(x => x.Organizer)
            .FirstOrDefaultAsync(x => x.Id == id, cancellationToken);
    }

    public async Task<IReadOnlyList<Event>> SearchAsync(string? query, bool includePastEvents, CancellationToken cancellationToken = default)
    {
        IQueryable<Event> q = _dbContext.Events.Include(x => x.Organizer);

        if (!includePastEvents)
        {
            q = q.Where(x => x.EndDateUtc >= DateTime.UtcNow);
        }

        if (!string.IsNullOrWhiteSpace(query))
        {
            var normalized = query.Trim().ToLower();
            q = q.Where(x =>
                x.Title.ToLower().Contains(normalized) ||
                x.Description.ToLower().Contains(normalized) ||
                x.Location.ToLower().Contains(normalized));
        }

        return await q.OrderBy(x => x.StartDateUtc).ToListAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<Event>> GetByOrganizerIdWithBookingsAsync(Guid organizerId, CancellationToken cancellationToken = default)
    {
        return await _dbContext.Events
            .Include(x => x.Bookings)
                .ThenInclude(x => x.Attendee)
            .Where(x => x.OrganizerId == organizerId)
            .OrderBy(x => x.StartDateUtc)
            .ToListAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<Event>> GetAllAsync(CancellationToken cancellationToken = default)
    {
        return await _dbContext.Events.Include(x => x.Organizer).AsNoTracking().ToListAsync(cancellationToken);
    }

    public async Task AddAsync(Event eventEntity, CancellationToken cancellationToken = default)
    {
        await _dbContext.Events.AddAsync(eventEntity, cancellationToken);
    }

    public Task DeleteAsync(Event eventEntity, CancellationToken cancellationToken = default)
    {
        _dbContext.Events.Remove(eventEntity);
        return Task.CompletedTask;
    }

    public Task SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        return _dbContext.SaveChangesAsync(cancellationToken);
    }
}
