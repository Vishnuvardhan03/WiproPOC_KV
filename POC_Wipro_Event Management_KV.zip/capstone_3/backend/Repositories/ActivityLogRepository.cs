using EventManagementSystem.Application.Interfaces.Persistence;
using EventManagementSystem.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace EventManagementSystem.Infrastructure.Persistence.Repositories;

public class ActivityLogRepository : IActivityLogRepository
{
    private readonly ApplicationDbContext _dbContext;

    public ActivityLogRepository(ApplicationDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task AddAsync(ActivityLog log, CancellationToken cancellationToken = default)
    {
        await _dbContext.ActivityLogs.AddAsync(log, cancellationToken);
    }

    public async Task<IReadOnlyList<ActivityLog>> GetLatestAsync(int count, CancellationToken cancellationToken = default)
    {
        return await _dbContext.ActivityLogs
            .Include(x => x.ActorUser)
            .OrderByDescending(x => x.CreatedAtUtc)
            .Take(count)
            .AsNoTracking()
            .ToListAsync(cancellationToken);
    }

    public Task SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        return _dbContext.SaveChangesAsync(cancellationToken);
    }
}
