using EventManagementSystem.Application.DTOs.Payments;
using EventManagementSystem.Application.Interfaces.Persistence;
using EventManagementSystem.Application.Interfaces.Services;
using EventManagementSystem.Domain.Entities;
using EventManagementSystem.Domain.Enums;

namespace EventManagementSystem.Application.Services;

public class PaymentService : IPaymentService
{
    private readonly IBookingRepository _bookingRepository;
    private readonly IPaymentRepository _paymentRepository;
    private readonly INotificationService _notificationService;
    private readonly IActivityLogService _activityLogService;

    public PaymentService(
        IBookingRepository bookingRepository,
        IPaymentRepository paymentRepository,
        INotificationService notificationService,
        IActivityLogService activityLogService)
    {
        _bookingRepository = bookingRepository;
        _paymentRepository = paymentRepository;
        _notificationService = notificationService;
        _activityLogService = activityLogService;
    }

    public async Task<PaymentResponseDto> CreatePaymentOrderAsync(Guid attendeeId, CreatePaymentRequestDto request, CancellationToken cancellationToken = default)
    {
        var booking = await _bookingRepository.GetByIdAsync(request.BookingId, cancellationToken)
            ?? throw new KeyNotFoundException("Booking not found.");

        if (booking.AttendeeId != attendeeId)
        {
            throw new UnauthorizedAccessException("You can only pay for your own booking.");
        }

        var existingPayment = await _paymentRepository.GetByBookingIdAsync(booking.Id, cancellationToken);
        if (existingPayment is not null && existingPayment.Status == PaymentStatus.Succeeded)
        {
            return ToResponse(existingPayment);
        }

        var payment = existingPayment ?? new Payment
        {
            BookingId = booking.Id,
            AmountInRupees = booking.Event.PriceInRupees,
            Currency = "INR",
            ProviderOrderId = $"DUMMY-ORDER-{Guid.NewGuid():N}".ToUpperInvariant(),
            ProviderPaymentId = $"DUMMY-PAY-{Guid.NewGuid():N}".ToUpperInvariant(),
            Status = PaymentStatus.Pending
        };

        if (existingPayment is null)
        {
            await _paymentRepository.AddAsync(payment, cancellationToken);
        }

        payment.UpdatedAtUtc = DateTime.UtcNow;
        await _paymentRepository.SaveChangesAsync(cancellationToken);

        await _activityLogService.LogAsync(attendeeId, "PAYMENT_ORDER_CREATED", "Payment", payment.Id, $"bookingId={booking.Id};amount={payment.AmountInRupees}", cancellationToken);

        return ToResponse(payment);
    }

    public async Task<PaymentResponseDto> CompletePaymentAsync(Guid attendeeId, CompletePaymentRequestDto request, CancellationToken cancellationToken = default)
    {
        var payment = await _paymentRepository.GetByProviderOrderIdAsync(request.ProviderOrderId.Trim(), cancellationToken)
            ?? throw new KeyNotFoundException("Payment order not found.");

        if (payment.Booking.AttendeeId != attendeeId)
        {
            throw new UnauthorizedAccessException("You can only complete your own payment.");
        }

        payment.ProviderPaymentId = request.ProviderPaymentId.Trim();
        payment.Status = request.Success ? PaymentStatus.Succeeded : PaymentStatus.Failed;
        payment.FailureReason = request.Success ? null : request.FailureReason?.Trim();
        payment.PaidAtUtc = request.Success ? DateTime.UtcNow : null;
        payment.UpdatedAtUtc = DateTime.UtcNow;

        await _paymentRepository.SaveChangesAsync(cancellationToken);

        var title = request.Success ? "Payment successful" : "Payment failed";
        var message = request.Success
            ? $"Your payment for event '{payment.Booking.Event.Title}' was successful."
            : $"Your payment for event '{payment.Booking.Event.Title}' failed. {payment.FailureReason}";
        await _notificationService.NotifyUserAsync(attendeeId, title, message, cancellationToken);

        await _activityLogService.LogAsync(attendeeId, "PAYMENT_COMPLETED", "Payment", payment.Id, $"success={request.Success};bookingId={payment.BookingId}", cancellationToken);

        return ToResponse(payment);
    }

    private static PaymentResponseDto ToResponse(Payment payment)
    {
        return new PaymentResponseDto
        {
            PaymentId = payment.Id,
            BookingId = payment.BookingId,
            AmountInRupees = payment.AmountInRupees,
            Currency = payment.Currency,
            ProviderOrderId = payment.ProviderOrderId,
            ProviderPaymentId = payment.ProviderPaymentId,
            Status = payment.Status.ToString(),
            CreatedAtUtc = payment.CreatedAtUtc,
            PaidAtUtc = payment.PaidAtUtc
        };
    }
}
