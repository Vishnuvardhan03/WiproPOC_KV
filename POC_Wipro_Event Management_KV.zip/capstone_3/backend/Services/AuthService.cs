using EventManagementSystem.Application.DTOs.Auth;
using EventManagementSystem.Application.Interfaces.Persistence;
using EventManagementSystem.Application.Interfaces.Security;
using EventManagementSystem.Application.Interfaces.Services;
using EventManagementSystem.Domain.Entities;
using EventManagementSystem.Domain.Enums;
using Microsoft.Extensions.Logging;
using System.Diagnostics;

namespace EventManagementSystem.Application.Services;

public class AuthService : IAuthService
{
    private readonly IUserRepository _userRepository;
    private readonly IPasswordHasher _passwordHasher;
    private readonly IJwtTokenGenerator _jwtTokenGenerator;
    private readonly ILogger<AuthService> _logger;

    public AuthService(IUserRepository userRepository, IPasswordHasher passwordHasher, IJwtTokenGenerator jwtTokenGenerator, ILogger<AuthService> logger)
    {
        _userRepository = userRepository;
        _passwordHasher = passwordHasher;
        _jwtTokenGenerator = jwtTokenGenerator;
        _logger = logger;
    }

    public async Task<AuthResponseDto> RegisterAsync(RegisterRequestDto request, CancellationToken cancellationToken = default)
    {
        var normalizedEmail = request.Email.Trim().ToLowerInvariant();
        var existingUser = await _userRepository.GetByEmailAsync(normalizedEmail, cancellationToken);
        if (existingUser is not null)
        {
            throw new InvalidOperationException("Email already registered.");
        }

        var (hash, salt) = _passwordHasher.HashPassword(request.Password);
        var user = new User
        {
            FullName = request.FullName.Trim(),
            Email = normalizedEmail,
            PasswordHash = hash,
            PasswordSalt = salt,
            Role = UserRole.Attendee
        };

        await _userRepository.AddAsync(user, cancellationToken);
        await _userRepository.SaveChangesAsync(cancellationToken);

        return BuildAuthResponse(user);
    }

    public async Task<AuthResponseDto> LoginAsync(LoginRequestDto request, CancellationToken cancellationToken = default)
    {
        var normalizedEmail = request.Email.Trim().ToLowerInvariant();

        var lookupStopwatch = Stopwatch.StartNew();
        var user = await _userRepository.GetByEmailAsync(normalizedEmail, cancellationToken)
            ?? throw new UnauthorizedAccessException("Invalid credentials.");
        lookupStopwatch.Stop();
        _logger.LogInformation("login_user_lookup email={Email} durationMs={DurationMs}", normalizedEmail, lookupStopwatch.ElapsedMilliseconds);

        var passwordStopwatch = Stopwatch.StartNew();
        var isValidPassword = _passwordHasher.VerifyPassword(request.Password, user.PasswordHash, user.PasswordSalt);
        passwordStopwatch.Stop();
        _logger.LogInformation("login_password_verify email={Email} durationMs={DurationMs}", normalizedEmail, passwordStopwatch.ElapsedMilliseconds);
        if (!isValidPassword)
        {
            throw new UnauthorizedAccessException("Invalid credentials.");
        }

        var tokenStopwatch = Stopwatch.StartNew();
        var response = BuildAuthResponse(user);
        tokenStopwatch.Stop();
        _logger.LogInformation("login_jwt_generate email={Email} durationMs={DurationMs}", normalizedEmail, tokenStopwatch.ElapsedMilliseconds);

        return response;
    }

    private AuthResponseDto BuildAuthResponse(User user)
    {
        var (token, expiresAtUtc) = _jwtTokenGenerator.Generate(user);

        return new AuthResponseDto
        {
            Token = token,
            ExpiresAtUtc = expiresAtUtc,
            UserId = user.Id,
            Email = user.Email,
            FullName = user.FullName,
            Role = user.Role.ToString()
        };
    }
}
