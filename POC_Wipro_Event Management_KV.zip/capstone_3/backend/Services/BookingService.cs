using EventManagementSystem.Application.DTOs.Bookings;
using EventManagementSystem.Application.Interfaces.Persistence;
using EventManagementSystem.Application.Interfaces.Services;
using EventManagementSystem.Domain.Entities;
using EventManagementSystem.Domain.Enums;

namespace EventManagementSystem.Application.Services;

public class BookingService : IBookingService
{
    private readonly IBookingRepository _bookingRepository;
    private readonly IEventRepository _eventRepository;

    public BookingService(IBookingRepository bookingRepository, IEventRepository eventRepository)
    {
        _bookingRepository = bookingRepository;
        _eventRepository = eventRepository;
    }

    public async Task<BookingResponseDto> BookAsync(Guid attendeeId, BookEventRequestDto request, CancellationToken cancellationToken = default)
    {
        if (request.EventId == Guid.Empty)
        {
            throw new InvalidOperationException("Event id is required.");
        }

        var eventEntity = await _eventRepository.GetByIdAsync(request.EventId, cancellationToken)
            ?? throw new KeyNotFoundException("Event not found.");

        if (eventEntity.StartDateUtc <= DateTime.UtcNow || eventEntity.EndDateUtc < DateTime.UtcNow)
        {
            throw new InvalidOperationException("Cannot book a past event.");
        }

        var existingBooking = await _bookingRepository.GetByEventAndAttendeeAsync(request.EventId, attendeeId, cancellationToken);
        if (existingBooking is not null && existingBooking.Status == BookingStatus.Booked)
        {
            throw new InvalidOperationException("Event is already booked by this attendee.");
        }

        if (existingBooking is not null && existingBooking.Status == BookingStatus.Pending)
        {
            throw new InvalidOperationException("Booking request is already pending admin approval.");
        }

        var approvedBookings = await _bookingRepository.CountActiveBookingsByEventIdAsync(request.EventId, cancellationToken);
        if (approvedBookings >= eventEntity.Capacity)
        {
            throw new InvalidOperationException("Event capacity reached.");
        }

        var booking = existingBooking ?? new Booking
        {
            AttendeeId = attendeeId,
            EventId = request.EventId,
            TicketNumber = await GenerateUniqueTicketNumberAsync(cancellationToken)
        };

        booking.Status = BookingStatus.Pending;
        booking.CancelledAtUtc = null;
        booking.CheckedInAtUtc = null;
        booking.UpdatedAtUtc = DateTime.UtcNow;

        if (existingBooking is null)
        {
            await _bookingRepository.AddAsync(booking, cancellationToken);
        }

        await _bookingRepository.SaveChangesAsync(cancellationToken);

        return new BookingResponseDto
        {
            BookingId = booking.Id,
            EventId = eventEntity.Id,
            EventTitle = eventEntity.Title,
            EventStartDateUtc = eventEntity.StartDateUtc,
            EventEndDateUtc = eventEntity.EndDateUtc,
            TicketNumber = booking.TicketNumber,
            Status = booking.Status.ToString(),
            CreatedAtUtc = booking.CreatedAtUtc,
            CheckedInAtUtc = booking.CheckedInAtUtc
        };
    }

    public async Task CancelAsync(Guid attendeeId, Guid bookingId, CancellationToken cancellationToken = default)
    {
        var booking = await _bookingRepository.GetByIdAsync(bookingId, cancellationToken)
            ?? throw new KeyNotFoundException("Booking not found.");

        if (booking.AttendeeId != attendeeId)
        {
            throw new UnauthorizedAccessException("You can only cancel your own bookings.");
        }

        if (booking.Status == BookingStatus.Cancelled)
        {
            return;
        }

        booking.Status = BookingStatus.Cancelled;
        booking.CancelledAtUtc = DateTime.UtcNow;
        booking.UpdatedAtUtc = DateTime.UtcNow;

        await _bookingRepository.SaveChangesAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<BookingResponseDto>> HistoryAsync(Guid attendeeId, CancellationToken cancellationToken = default)
    {
        var bookings = await _bookingRepository.GetByAttendeeIdAsync(attendeeId, cancellationToken);

        return bookings.Select(booking => new BookingResponseDto
        {
            BookingId = booking.Id,
            EventId = booking.EventId,
            EventTitle = booking.Event.Title,
            EventStartDateUtc = booking.Event.StartDateUtc,
            EventEndDateUtc = booking.Event.EndDateUtc,
            TicketNumber = booking.TicketNumber,
            Status = booking.Status.ToString(),
            CreatedAtUtc = booking.CreatedAtUtc,
            CheckedInAtUtc = booking.CheckedInAtUtc
        }).ToList();
    }

    public async Task<BookingResponseDto> CheckInAsync(string ticketNumber, CancellationToken cancellationToken = default)
    {
        var normalizedTicketNumber = ticketNumber.Trim().ToUpperInvariant();
        var booking = await _bookingRepository.GetByTicketNumberAsync(normalizedTicketNumber, cancellationToken)
            ?? throw new KeyNotFoundException("Ticket not found.");

        if (booking.Status != BookingStatus.Booked)
        {
            throw new InvalidOperationException("Only approved bookings can be checked in.");
        }

        booking.CheckedInAtUtc ??= DateTime.UtcNow;
        booking.UpdatedAtUtc = DateTime.UtcNow;

        await _bookingRepository.SaveChangesAsync(cancellationToken);

        return new BookingResponseDto
        {
            BookingId = booking.Id,
            EventId = booking.EventId,
            EventTitle = booking.Event.Title,
            EventStartDateUtc = booking.Event.StartDateUtc,
            EventEndDateUtc = booking.Event.EndDateUtc,
            TicketNumber = booking.TicketNumber,
            Status = booking.Status.ToString(),
            CreatedAtUtc = booking.CreatedAtUtc,
            CheckedInAtUtc = booking.CheckedInAtUtc
        };
    }

    private async Task<string> GenerateUniqueTicketNumberAsync(CancellationToken cancellationToken)
    {
        for (var i = 0; i < 5; i++)
        {
            var candidate = $"TCK-{DateTime.UtcNow:yyyyMMdd}-{Guid.NewGuid():N}"[..26].ToUpperInvariant();
            var exists = await _bookingRepository.TicketNumberExistsAsync(candidate, cancellationToken);
            if (!exists)
            {
                return candidate;
            }
        }

        throw new InvalidOperationException("Unable to generate unique ticket number.");
    }
}
