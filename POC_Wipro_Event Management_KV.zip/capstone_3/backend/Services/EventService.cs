using EventManagementSystem.Application.DTOs.Events;
using EventManagementSystem.Application.Interfaces.Persistence;
using EventManagementSystem.Application.Interfaces.Services;
using EventManagementSystem.Domain.Entities;
using EventManagementSystem.Domain.Enums;

namespace EventManagementSystem.Application.Services;

public class EventService : IEventService
{
    private readonly IEventRepository _eventRepository;
    private readonly IBookingRepository _bookingRepository;
    private readonly IEventChangeRequestRepository _eventChangeRequestRepository;
    private readonly IUserRepository _userRepository;
    private readonly INotificationService _notificationService;
    private readonly IActivityLogService _activityLogService;

    public EventService(
        IEventRepository eventRepository,
        IBookingRepository bookingRepository,
        IEventChangeRequestRepository eventChangeRequestRepository,
        IUserRepository userRepository,
        INotificationService notificationService,
        IActivityLogService activityLogService)
    {
        _eventRepository = eventRepository;
        _bookingRepository = bookingRepository;
        _eventChangeRequestRepository = eventChangeRequestRepository;
        _userRepository = userRepository;
        _notificationService = notificationService;
        _activityLogService = activityLogService;
    }

    public async Task<EventResponseDto> CreateAsync(Guid organizerId, CreateEventRequestDto request, CancellationToken cancellationToken = default)
    {
        ValidateEventWindow(request.StartDateUtc, request.EndDateUtc);

        var eventEntity = new Event
        {
            Title = request.Title.Trim(),
            Description = request.Description.Trim(),
            Location = request.Location.Trim(),
            StartDateUtc = request.StartDateUtc,
            EndDateUtc = request.EndDateUtc,
            Capacity = request.Capacity,
            PriceInRupees = request.PriceInRupees,
            OrganizerId = organizerId
        };

        await _eventRepository.AddAsync(eventEntity, cancellationToken);
        await _eventRepository.SaveChangesAsync(cancellationToken);

        var reloadedEvent = await _eventRepository.GetByIdAsync(eventEntity.Id, cancellationToken) ?? eventEntity;
        var bookedCount = await _bookingRepository.CountActiveBookingsByEventIdAsync(eventEntity.Id, cancellationToken);
        return MapEvent(reloadedEvent, bookedCount);
    }

    public async Task<EventResponseDto> UpdateAsync(Guid requesterId, bool isAdmin, Guid eventId, UpdateEventRequestDto request, CancellationToken cancellationToken = default)
    {
        ValidateEventWindow(request.StartDateUtc, request.EndDateUtc);

        var eventEntity = await _eventRepository.GetByIdAsync(eventId, cancellationToken)
            ?? throw new KeyNotFoundException("Event not found.");

        if (!isAdmin && eventEntity.OrganizerId != requesterId)
        {
            throw new UnauthorizedAccessException("You can only update your own events.");
        }

        if (!isAdmin)
        {
            var pendingRequest = await _eventChangeRequestRepository.GetPendingByEventIdAsync(eventId, cancellationToken);
            if (pendingRequest is not null)
            {
                pendingRequest.Title = request.Title.Trim();
                pendingRequest.Description = request.Description.Trim();
                pendingRequest.Location = request.Location.Trim();
                pendingRequest.StartDateUtc = request.StartDateUtc;
                pendingRequest.EndDateUtc = request.EndDateUtc;
                pendingRequest.Capacity = request.Capacity;
                pendingRequest.PriceInRupees = request.PriceInRupees;
                pendingRequest.UpdatedAtUtc = DateTime.UtcNow;
            }
            else
            {
                pendingRequest = new EventChangeRequest
                {
                    EventId = eventEntity.Id,
                    RequestedByOrganizerId = requesterId,
                    Title = request.Title.Trim(),
                    Description = request.Description.Trim(),
                    Location = request.Location.Trim(),
                    StartDateUtc = request.StartDateUtc,
                    EndDateUtc = request.EndDateUtc,
                    Capacity = request.Capacity,
                    PriceInRupees = request.PriceInRupees,
                    Status = EventChangeRequestStatus.Pending
                };
                await _eventChangeRequestRepository.AddAsync(pendingRequest, cancellationToken);
            }

            await _eventChangeRequestRepository.SaveChangesAsync(cancellationToken);

            var admins = await _userRepository.GetByRoleAsync(UserRole.Admin, cancellationToken);
            foreach (var admin in admins)
            {
                await _notificationService.NotifyUserAsync(
                    admin.Id,
                    "Event change approval needed",
                    $"Organizer requested update approval for event '{eventEntity.Title}'.",
                    cancellationToken);
            }

            await _activityLogService.LogAsync(requesterId, "EVENT_CHANGE_REQUESTED", "Event", eventId, "Organizer submitted event change request.", cancellationToken);

            var bookedCount = await _bookingRepository.CountActiveBookingsByEventIdAsync(eventId, cancellationToken);
            return MapEvent(eventEntity, bookedCount);
        }

        eventEntity.Title = request.Title.Trim();
        eventEntity.Description = request.Description.Trim();
        eventEntity.Location = request.Location.Trim();
        eventEntity.StartDateUtc = request.StartDateUtc;
        eventEntity.EndDateUtc = request.EndDateUtc;
        eventEntity.Capacity = request.Capacity;
        eventEntity.PriceInRupees = request.PriceInRupees;
        eventEntity.UpdatedAtUtc = DateTime.UtcNow;

        await _eventRepository.SaveChangesAsync(cancellationToken);

        await _activityLogService.LogAsync(requesterId, "EVENT_UPDATED_BY_ADMIN", "Event", eventId, "Admin applied event changes directly.", cancellationToken);

        var adminBookedCount = await _bookingRepository.CountActiveBookingsByEventIdAsync(eventId, cancellationToken);
        return MapEvent(eventEntity, adminBookedCount);
    }

    public async Task DeleteAsync(Guid requesterId, bool isAdmin, Guid eventId, CancellationToken cancellationToken = default)
    {
        var eventEntity = await _eventRepository.GetByIdAsync(eventId, cancellationToken)
            ?? throw new KeyNotFoundException("Event not found.");

        if (!isAdmin && eventEntity.OrganizerId != requesterId)
        {
            throw new UnauthorizedAccessException("You can only delete your own events.");
        }

        await _eventRepository.DeleteAsync(eventEntity, cancellationToken);
        await _eventRepository.SaveChangesAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<EventResponseDto>> SearchAsync(string? query, bool includePastEvents, CancellationToken cancellationToken = default)
    {
        var events = await _eventRepository.SearchAsync(query, includePastEvents, cancellationToken);
        if (events.Count == 0) return [];

        // Single batch query instead of N+1
        var counts = await _bookingRepository.GetActiveBookingCountsByEventIdsAsync(
            events.Select(e => e.Id), cancellationToken);

        return events
            .Select(e => MapEvent(e, counts.GetValueOrDefault(e.Id, 0)))
            .ToList();
    }

    public async Task<OrganizerEventsDashboardDto> GetOrganizerDashboardAsync(Guid organizerId, CancellationToken cancellationToken = default)
    {
        var events = await _eventRepository.GetByOrganizerIdWithBookingsAsync(organizerId, cancellationToken);
        var now = DateTime.UtcNow;

        static OrganizerEventWithAttendeesDto MapOrganizerEvent(Event ev)
        {
            return new OrganizerEventWithAttendeesDto
            {
                EventId = ev.Id,
                Title = ev.Title,
                Location = ev.Location,
                StartDateUtc = ev.StartDateUtc,
                EndDateUtc = ev.EndDateUtc,
                Capacity = ev.Capacity,
                PriceInRupees = ev.PriceInRupees,
                Attendees = ev.Bookings
                    .Select(b => new EventAttendeeDto
                    {
                        AttendeeId = b.AttendeeId,
                        FullName = b.Attendee?.FullName ?? string.Empty,
                        Email = b.Attendee?.Email ?? string.Empty,
                        BookingStatus = b.Status.ToString(),
                        TicketNumber = b.TicketNumber,
                        CheckedInAtUtc = b.CheckedInAtUtc
                    })
                    .ToList()
            };
        }

        return new OrganizerEventsDashboardDto
        {
            UpcomingEvents = events.Where(x => x.EndDateUtc >= now).Select(MapOrganizerEvent).ToList(),
            PastEvents = events.Where(x => x.EndDateUtc < now).Select(MapOrganizerEvent).ToList()
        };
    }

    private static EventResponseDto MapEvent(Event eventEntity, int bookedCount)
    {
        return new EventResponseDto
        {
            Id = eventEntity.Id,
            Title = eventEntity.Title,
            Description = eventEntity.Description,
            Location = eventEntity.Location,
            StartDateUtc = eventEntity.StartDateUtc,
            EndDateUtc = eventEntity.EndDateUtc,
            Capacity = eventEntity.Capacity,
            PriceInRupees = eventEntity.PriceInRupees,
            ConfirmedBookings = bookedCount,
            OrganizerId = eventEntity.OrganizerId,
            OrganizerName = eventEntity.Organizer?.FullName ?? string.Empty
        };
    }

    private static void ValidateEventWindow(DateTime startDateUtc, DateTime endDateUtc)
    {
        if (startDateUtc >= endDateUtc)
        {
            throw new InvalidOperationException("Event start date must be before end date.");
        }

        if (startDateUtc <= DateTime.UtcNow)
        {
            throw new InvalidOperationException("Event start date must be in the future.");
        }
    }
}
