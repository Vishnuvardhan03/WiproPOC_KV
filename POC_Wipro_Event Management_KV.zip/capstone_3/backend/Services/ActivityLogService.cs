using EventManagementSystem.Application.Interfaces.Persistence;
using EventManagementSystem.Application.Interfaces.Services;
using EventManagementSystem.Domain.Entities;

namespace EventManagementSystem.Application.Services;

public class ActivityLogService : IActivityLogService
{
    private readonly IActivityLogRepository _activityLogRepository;

    public ActivityLogService(IActivityLogRepository activityLogRepository)
    {
        _activityLogRepository = activityLogRepository;
    }

    public async Task LogAsync(Guid? actorUserId, string action, string entityType, Guid? entityId, string metadata, CancellationToken cancellationToken = default)
    {
        var log = new ActivityLog
        {
            ActorUserId = actorUserId,
            Action = action,
            EntityType = entityType,
            EntityId = entityId,
            Metadata = metadata
        };

        await _activityLogRepository.AddAsync(log, cancellationToken);
        await _activityLogRepository.SaveChangesAsync(cancellationToken);
    }
}
