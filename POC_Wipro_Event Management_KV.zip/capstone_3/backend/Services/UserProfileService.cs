using EventManagementSystem.Application.DTOs.Users;
using EventManagementSystem.Application.Interfaces.Persistence;
using EventManagementSystem.Application.Interfaces.Services;
using EventManagementSystem.Domain.Entities;
using EventManagementSystem.Domain.Enums;

namespace EventManagementSystem.Application.Services;

public class UserProfileService : IUserProfileService
{
    private readonly IUserRepository _userRepository;
    private readonly IRoleChangeRequestRepository _roleChangeRequestRepository;
    private readonly INotificationService _notificationService;
    private readonly IActivityLogService _activityLogService;

    public UserProfileService(
        IUserRepository userRepository,
        IRoleChangeRequestRepository roleChangeRequestRepository,
        INotificationService notificationService,
        IActivityLogService activityLogService)
    {
        _userRepository = userRepository;
        _roleChangeRequestRepository = roleChangeRequestRepository;
        _notificationService = notificationService;
        _activityLogService = activityLogService;
    }

    public async Task<UserProfileDto> GetAsync(Guid userId, CancellationToken cancellationToken = default)
    {
        var user = await _userRepository.GetByIdAsync(userId, cancellationToken)
            ?? throw new KeyNotFoundException("User not found.");

        return new UserProfileDto
        {
            Id = user.Id,
            FullName = user.FullName,
            Email = user.Email,
            Role = user.Role.ToString()
        };
    }

    public async Task<UserProfileDto> UpdateAsync(Guid userId, UpdateProfileRequestDto request, CancellationToken cancellationToken = default)
    {
        var user = await _userRepository.GetByIdAsync(userId, cancellationToken)
            ?? throw new KeyNotFoundException("User not found.");

        user.FullName = request.FullName.Trim();
        user.UpdatedAtUtc = DateTime.UtcNow;

        await _userRepository.SaveChangesAsync(cancellationToken);

        return new UserProfileDto
        {
            Id = user.Id,
            FullName = user.FullName,
            Email = user.Email,
            Role = user.Role.ToString()
        };
    }

    public async Task RequestRoleChangeAsync(Guid userId, RequestRoleChangeDto request, CancellationToken cancellationToken = default)
    {
        var user = await _userRepository.GetByIdAsync(userId, cancellationToken)
            ?? throw new KeyNotFoundException("User not found.");

        if (!Enum.TryParse<UserRole>(request.Role.Trim(), true, out var requestedRole))
        {
            throw new InvalidOperationException("Invalid role requested.");
        }

        if (requestedRole == UserRole.Attendee)
        {
            throw new InvalidOperationException("No role change needed for attendee.");
        }

        if (user.Role == requestedRole)
        {
            throw new InvalidOperationException("User already has this role.");
        }

        var existingPending = await _roleChangeRequestRepository.GetPendingByUserIdAsync(userId, cancellationToken);
        if (existingPending is not null)
        {
            throw new InvalidOperationException("A role change request is already pending.");
        }

        var roleRequest = new RoleChangeRequest
        {
            UserId = userId,
            RequestedRole = requestedRole,
            Status = RoleRequestStatus.Pending
        };

        await _roleChangeRequestRepository.AddAsync(roleRequest, cancellationToken);
        await _roleChangeRequestRepository.SaveChangesAsync(cancellationToken);

        var admins = await _userRepository.GetByRoleAsync(UserRole.Admin, cancellationToken);
        foreach (var admin in admins)
        {
            await _notificationService.NotifyUserAsync(
                admin.Id,
                "Role change request",
                $"{user.FullName} requested role change to {requestedRole}.",
                cancellationToken);
        }

        await _activityLogService.LogAsync(userId, "ROLE_CHANGE_REQUESTED", "RoleChangeRequest", roleRequest.Id, $"requestedRole={requestedRole}", cancellationToken);
    }
}
