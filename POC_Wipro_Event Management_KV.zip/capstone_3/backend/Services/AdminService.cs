using EventManagementSystem.Application.DTOs.Admin;
using EventManagementSystem.Application.DTOs.Bookings;
using EventManagementSystem.Application.Interfaces.Persistence;
using EventManagementSystem.Application.Interfaces.Services;
using EventManagementSystem.Domain.Entities;
using EventManagementSystem.Domain.Enums;

namespace EventManagementSystem.Application.Services;

public class AdminService : IAdminService
{
    private readonly IUserRepository _userRepository;
    private readonly IEventRepository _eventRepository;
    private readonly IBookingRepository _bookingRepository;
    private readonly IRoleChangeRequestRepository _roleChangeRequestRepository;
    private readonly IEventChangeRequestRepository _eventChangeRequestRepository;
    private readonly IActivityLogRepository _activityLogRepository;
    private readonly IPaymentRepository _paymentRepository;
    private readonly INotificationService _notificationService;

    public AdminService(
        IUserRepository userRepository,
        IEventRepository eventRepository,
        IBookingRepository bookingRepository,
        IRoleChangeRequestRepository roleChangeRequestRepository,
        IEventChangeRequestRepository eventChangeRequestRepository,
        IActivityLogRepository activityLogRepository,
        IPaymentRepository paymentRepository,
        INotificationService notificationService)
    {
        _userRepository = userRepository;
        _eventRepository = eventRepository;
        _bookingRepository = bookingRepository;
        _roleChangeRequestRepository = roleChangeRequestRepository;
        _eventChangeRequestRepository = eventChangeRequestRepository;
        _activityLogRepository = activityLogRepository;
        _paymentRepository = paymentRepository;
        _notificationService = notificationService;
    }

    public async Task<IReadOnlyList<UserSummaryDto>> GetUsersAsync(CancellationToken cancellationToken = default)
    {
        var users = await _userRepository.GetAllAsync(cancellationToken);
        return users
            .OrderBy(x => x.FullName)
            .Select(x => new UserSummaryDto
            {
                Id = x.Id,
                FullName = x.FullName,
                Email = x.Email,
                Role = x.Role.ToString()
            })
            .ToList();
    }

    public async Task UpdateUserRoleAsync(Guid userId, string role, CancellationToken cancellationToken = default)
    {
        var user = await _userRepository.GetByIdAsync(userId, cancellationToken)
            ?? throw new KeyNotFoundException("User not found.");

        if (!Enum.TryParse<UserRole>(role, true, out var parsedRole))
        {
            throw new InvalidOperationException("Invalid role.");
        }

        user.Role = parsedRole;
        user.UpdatedAtUtc = DateTime.UtcNow;
        await _userRepository.SaveChangesAsync(cancellationToken);

        await _notificationService.NotifyUserAsync(user.Id, "Role updated", $"Your role has been updated to {parsedRole}.", cancellationToken);
    }

    public async Task<IReadOnlyList<BookingResponseDto>> GetBookingsAsync(CancellationToken cancellationToken = default)
    {
        var bookings = await _bookingRepository.GetAllAsync(cancellationToken);
        return bookings.Select(MapBooking).ToList();
    }

    public async Task<IReadOnlyList<BookingResponseDto>> GetBookingsByEventAsync(Guid eventId, CancellationToken cancellationToken = default)
    {
        var bookings = await _bookingRepository.GetByEventIdAsync(eventId, cancellationToken);
        return bookings.Select(MapBooking).ToList();
    }

    public async Task ApproveBookingAsync(Guid bookingId, CancellationToken cancellationToken = default)
    {
        var booking = await _bookingRepository.GetByIdAsync(bookingId, cancellationToken)
            ?? throw new KeyNotFoundException("Booking not found.");

        if (booking.Status == BookingStatus.Booked)
        {
            return;
        }

        if (booking.Status != BookingStatus.Pending)
        {
            throw new InvalidOperationException("Only pending bookings can be approved.");
        }

        var activeBookings = await _bookingRepository.CountActiveBookingsByEventIdAsync(booking.EventId, cancellationToken);
        if (activeBookings >= booking.Event.Capacity)
        {
            throw new InvalidOperationException("Event capacity reached.");
        }

        if (booking.Event.PriceInRupees > 0)
        {
            var payment = await _paymentRepository.GetByBookingIdAsync(booking.Id, cancellationToken);
            if (payment is null || payment.Status != PaymentStatus.Succeeded)
            {
                throw new InvalidOperationException("Payment is required before booking approval for paid events.");
            }
        }

        booking.Status = BookingStatus.Booked;
        booking.UpdatedAtUtc = DateTime.UtcNow;

        await _bookingRepository.SaveChangesAsync(cancellationToken);

        await _notificationService.NotifyUserAsync(booking.AttendeeId, "Booking approved", $"Your booking for '{booking.Event.Title}' has been approved.", cancellationToken);
    }

    public async Task DeclineBookingAsync(Guid bookingId, CancellationToken cancellationToken = default)
    {
        var booking = await _bookingRepository.GetByIdAsync(bookingId, cancellationToken)
            ?? throw new KeyNotFoundException("Booking not found.");

        if (booking.Status == BookingStatus.Declined)
        {
            return;
        }

        if (booking.Status != BookingStatus.Pending)
        {
            throw new InvalidOperationException("Only pending bookings can be declined.");
        }

        booking.Status = BookingStatus.Declined;
        booking.UpdatedAtUtc = DateTime.UtcNow;

        await _bookingRepository.SaveChangesAsync(cancellationToken);

        await _notificationService.NotifyUserAsync(booking.AttendeeId, "Booking declined", $"Your booking for '{booking.Event.Title}' was declined.", cancellationToken);
    }

    public async Task CancelBookingAsync(Guid bookingId, CancellationToken cancellationToken = default)
    {
        var booking = await _bookingRepository.GetByIdAsync(bookingId, cancellationToken)
            ?? throw new KeyNotFoundException("Booking not found.");

        if (booking.Status == BookingStatus.Cancelled)
        {
            return;
        }

        booking.Status = BookingStatus.Cancelled;
        booking.CancelledAtUtc = DateTime.UtcNow;
        booking.UpdatedAtUtc = DateTime.UtcNow;

        await _bookingRepository.SaveChangesAsync(cancellationToken);

        await _notificationService.NotifyUserAsync(booking.AttendeeId, "Booking cancelled", $"Your booking for '{booking.Event.Title}' has been cancelled.", cancellationToken);
    }

    public async Task<IReadOnlyList<RoleChangeRequestDto>> GetPendingRoleRequestsAsync(CancellationToken cancellationToken = default)
    {
        var requests = await _roleChangeRequestRepository.GetPendingAsync(cancellationToken);
        return requests.Select(x => new RoleChangeRequestDto
        {
            RequestId = x.Id,
            UserId = x.UserId,
            UserName = x.User.FullName,
            UserEmail = x.User.Email,
            CurrentRole = x.User.Role.ToString(),
            RequestedRole = x.RequestedRole.ToString(),
            Status = x.Status.ToString(),
            AdminComment = x.AdminComment,
            CreatedAtUtc = x.CreatedAtUtc
        }).ToList();
    }

    public async Task ApproveRoleRequestAsync(Guid requestId, Guid adminUserId, string? comment, CancellationToken cancellationToken = default)
    {
        var request = await _roleChangeRequestRepository.GetByIdAsync(requestId, cancellationToken)
            ?? throw new KeyNotFoundException("Role change request not found.");

        if (request.Status != RoleRequestStatus.Pending)
        {
            throw new InvalidOperationException("Only pending role requests can be approved.");
        }

        request.Status = RoleRequestStatus.Approved;
        request.AdminComment = comment?.Trim();
        request.ReviewedByAdminId = adminUserId;
        request.ReviewedAtUtc = DateTime.UtcNow;
        request.UpdatedAtUtc = DateTime.UtcNow;

        request.User.Role = request.RequestedRole;
        request.User.UpdatedAtUtc = DateTime.UtcNow;

        await _roleChangeRequestRepository.SaveChangesAsync(cancellationToken);

        await AddActivityLogAsync(adminUserId, "ROLE_REQUEST_APPROVED", "RoleChangeRequest", request.Id, $"userId={request.UserId};requestedRole={request.RequestedRole}", cancellationToken);
        await _notificationService.NotifyUserAsync(request.UserId, "Role request approved", $"Your role request for {request.RequestedRole} has been approved.", cancellationToken);
    }

    public async Task RejectRoleRequestAsync(Guid requestId, Guid adminUserId, string? comment, CancellationToken cancellationToken = default)
    {
        var request = await _roleChangeRequestRepository.GetByIdAsync(requestId, cancellationToken)
            ?? throw new KeyNotFoundException("Role change request not found.");

        if (request.Status != RoleRequestStatus.Pending)
        {
            throw new InvalidOperationException("Only pending role requests can be rejected.");
        }

        request.Status = RoleRequestStatus.Rejected;
        request.AdminComment = comment?.Trim();
        request.ReviewedByAdminId = adminUserId;
        request.ReviewedAtUtc = DateTime.UtcNow;
        request.UpdatedAtUtc = DateTime.UtcNow;

        await _roleChangeRequestRepository.SaveChangesAsync(cancellationToken);

        await AddActivityLogAsync(adminUserId, "ROLE_REQUEST_REJECTED", "RoleChangeRequest", request.Id, $"userId={request.UserId};requestedRole={request.RequestedRole}", cancellationToken);
        await _notificationService.NotifyUserAsync(request.UserId, "Role request rejected", "Your role change request has been rejected.", cancellationToken);
    }

    public async Task<IReadOnlyList<EventChangeRequestDto>> GetPendingEventChangeRequestsAsync(CancellationToken cancellationToken = default)
    {
        var requests = await _eventChangeRequestRepository.GetPendingAsync(cancellationToken);
        return requests.Select(x => new EventChangeRequestDto
        {
            RequestId = x.Id,
            EventId = x.EventId,
            EventTitle = x.Event.Title,
            RequestedByOrganizerId = x.RequestedByOrganizerId,
            RequestedByOrganizerName = x.RequestedByOrganizer.FullName,
            Status = x.Status.ToString(),
            AdminComment = x.AdminComment,
            CreatedAtUtc = x.CreatedAtUtc,
            ProposedTitle = x.Title,
            ProposedDescription = x.Description,
            ProposedLocation = x.Location,
            ProposedStartDateUtc = x.StartDateUtc,
            ProposedEndDateUtc = x.EndDateUtc,
            ProposedCapacity = x.Capacity,
            ProposedPriceInRupees = x.PriceInRupees
        }).ToList();
    }

    public async Task ApproveEventChangeRequestAsync(Guid requestId, Guid adminUserId, string? comment, CancellationToken cancellationToken = default)
    {
        var request = await _eventChangeRequestRepository.GetByIdAsync(requestId, cancellationToken)
            ?? throw new KeyNotFoundException("Event change request not found.");

        if (request.Status != EventChangeRequestStatus.Pending)
        {
            throw new InvalidOperationException("Only pending event change requests can be approved.");
        }

        request.Event.Title = request.Title;
        request.Event.Description = request.Description;
        request.Event.Location = request.Location;
        request.Event.StartDateUtc = request.StartDateUtc;
        request.Event.EndDateUtc = request.EndDateUtc;
        request.Event.Capacity = request.Capacity;
        request.Event.PriceInRupees = request.PriceInRupees;
        request.Event.UpdatedAtUtc = DateTime.UtcNow;

        request.Status = EventChangeRequestStatus.Approved;
        request.AdminComment = comment?.Trim();
        request.ReviewedByAdminId = adminUserId;
        request.ReviewedAtUtc = DateTime.UtcNow;
        request.UpdatedAtUtc = DateTime.UtcNow;

        await _eventChangeRequestRepository.SaveChangesAsync(cancellationToken);

        await AddActivityLogAsync(adminUserId, "EVENT_CHANGE_APPROVED", "EventChangeRequest", request.Id, $"eventId={request.EventId}", cancellationToken);
        await _notificationService.NotifyUserAsync(request.RequestedByOrganizerId, "Event update approved", $"Your changes for event '{request.Event.Title}' were approved.", cancellationToken);
    }

    public async Task RejectEventChangeRequestAsync(Guid requestId, Guid adminUserId, string? comment, CancellationToken cancellationToken = default)
    {
        var request = await _eventChangeRequestRepository.GetByIdAsync(requestId, cancellationToken)
            ?? throw new KeyNotFoundException("Event change request not found.");

        if (request.Status != EventChangeRequestStatus.Pending)
        {
            throw new InvalidOperationException("Only pending event change requests can be rejected.");
        }

        request.Status = EventChangeRequestStatus.Rejected;
        request.AdminComment = comment?.Trim();
        request.ReviewedByAdminId = adminUserId;
        request.ReviewedAtUtc = DateTime.UtcNow;
        request.UpdatedAtUtc = DateTime.UtcNow;

        await _eventChangeRequestRepository.SaveChangesAsync(cancellationToken);

        await AddActivityLogAsync(adminUserId, "EVENT_CHANGE_REJECTED", "EventChangeRequest", request.Id, $"eventId={request.EventId}", cancellationToken);
        await _notificationService.NotifyUserAsync(request.RequestedByOrganizerId, "Event update rejected", $"Your changes for event '{request.Event.Title}' were rejected.", cancellationToken);
    }

    public async Task<IReadOnlyList<ActivityLogDto>> GetActivityLogsAsync(int count, CancellationToken cancellationToken = default)
    {
        var safeCount = Math.Clamp(count, 1, 200);
        var logs = await _activityLogRepository.GetLatestAsync(safeCount, cancellationToken);
        return logs.Select(x => new ActivityLogDto
        {
            Id = x.Id,
            ActorUserId = x.ActorUserId,
            ActorUserName = x.ActorUser?.FullName ?? string.Empty,
            Action = x.Action,
            EntityType = x.EntityType,
            EntityId = x.EntityId,
            Metadata = x.Metadata,
            CreatedAtUtc = x.CreatedAtUtc
        }).ToList();
    }

    public async Task<ReportSummaryDto> GetReportAsync(CancellationToken cancellationToken = default)
    {
        var users = await _userRepository.GetAllAsync(cancellationToken);
        var events = await _eventRepository.GetAllAsync(cancellationToken);
        var totalBookings = await _bookingRepository.CountAllAsync(cancellationToken);
        var approvedBookings = await _bookingRepository.CountApprovedAsync(cancellationToken);
        var cancelledBookings = await _bookingRepository.CountCancelledAsync(cancellationToken);
        var checkedInAttendees = await _bookingRepository.CountCheckedInAsync(cancellationToken);
        var totalCapacity = events.Sum(x => x.Capacity);

        return new ReportSummaryDto
        {
            TotalUsers = users.Count,
            TotalAdmins = users.Count(x => x.Role == UserRole.Admin),
            TotalOrganizers = users.Count(x => x.Role == UserRole.Organizer),
            TotalAttendees = users.Count(x => x.Role == UserRole.Attendee),
            TotalEvents = events.Count,
            UpcomingEvents = events.Count(x => x.StartDateUtc >= DateTime.UtcNow),
            CompletedEvents = events.Count(x => x.EndDateUtc < DateTime.UtcNow),
            TotalBookings = totalBookings,
            CancelledBookings = cancelledBookings,
            CheckedInAttendees = checkedInAttendees,
            ActiveEvents = events.Count(x => x.EndDateUtc >= DateTime.UtcNow),
            TotalCapacity = totalCapacity,
            OccupancyPercentage = totalCapacity == 0 ? 0 : Math.Round((decimal)approvedBookings / totalCapacity * 100, 2)
        };
    }

    private async Task AddActivityLogAsync(Guid actorUserId, string action, string entityType, Guid? entityId, string metadata, CancellationToken cancellationToken)
    {
        await _activityLogRepository.AddAsync(new ActivityLog
        {
            ActorUserId = actorUserId,
            Action = action,
            EntityType = entityType,
            EntityId = entityId,
            Metadata = metadata
        }, cancellationToken);
        await _activityLogRepository.SaveChangesAsync(cancellationToken);
    }

    private static BookingResponseDto MapBooking(Booking booking)
    {
        return new BookingResponseDto
        {
            BookingId = booking.Id,
            EventId = booking.EventId,
            AttendeeId = booking.AttendeeId,
            AttendeeName = booking.Attendee?.FullName ?? string.Empty,
            AttendeeEmail = booking.Attendee?.Email ?? string.Empty,
            EventTitle = booking.Event?.Title ?? string.Empty,
            EventStartDateUtc = booking.Event?.StartDateUtc ?? default,
            EventEndDateUtc = booking.Event?.EndDateUtc ?? default,
            TicketNumber = booking.TicketNumber,
            Status = booking.Status.ToString(),
            CreatedAtUtc = booking.CreatedAtUtc,
            CheckedInAtUtc = booking.CheckedInAtUtc
        };
    }
}
