using EventManagementSystem.Application.Interfaces.Persistence;
using EventManagementSystem.Application.Interfaces.Security;
using EventManagementSystem.Infrastructure.Persistence;
using EventManagementSystem.Infrastructure.Persistence.Repositories;
using EventManagementSystem.Infrastructure.Security;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace EventManagementSystem.Infrastructure.DependencyInjection;

public static class InfrastructureServiceRegistration
{
    public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
    {
        services.Configure<JwtOptions>(options =>
            configuration.GetSection(JwtOptions.SectionName).Bind(options));

        services.AddDbContext<ApplicationDbContext>(options =>
        {
            var provider = configuration["Database:Provider"] ?? "Sqlite";
            if (provider.Equals("SqlServer", StringComparison.OrdinalIgnoreCase))
            {
                options.UseSqlServer(configuration.GetConnectionString("SqlServerConnection")
                    ?? configuration.GetConnectionString("DefaultConnection"));
                return;
            }

            options.UseSqlite(configuration.GetConnectionString("DefaultConnection"));
        });

        services.AddScoped<IUserRepository, UserRepository>();
        services.AddScoped<IEventRepository, EventRepository>();
        services.AddScoped<IBookingRepository, BookingRepository>();
        services.AddScoped<IRoleChangeRequestRepository, RoleChangeRequestRepository>();
        services.AddScoped<IEventChangeRequestRepository, EventChangeRequestRepository>();
        services.AddScoped<IActivityLogRepository, ActivityLogRepository>();
        services.AddScoped<INotificationRepository, NotificationRepository>();
        services.AddScoped<IPaymentRepository, PaymentRepository>();

        services.AddScoped<IPasswordHasher, PasswordHasher>();
        services.AddScoped<IJwtTokenGenerator, JwtTokenGenerator>();

        return services;
    }
}
