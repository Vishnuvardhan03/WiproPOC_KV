using EventManagementSystem.Application.Interfaces.Services;
using EventManagementSystem.Application.Services;
using Microsoft.Extensions.DependencyInjection;

namespace EventManagementSystem.Application.DependencyInjection;

public static class ApplicationServiceRegistration
{
    public static IServiceCollection AddApplication(this IServiceCollection services)
    {
        services.AddScoped<IAuthService, AuthService>();
        services.AddScoped<IEventService, EventService>();
        services.AddScoped<IBookingService, BookingService>();
        services.AddScoped<IAdminService, AdminService>();
        services.AddScoped<IUserProfileService, UserProfileService>();
        services.AddScoped<INotificationService, NotificationService>();
        services.AddScoped<IPaymentService, PaymentService>();
        services.AddScoped<IActivityLogService, ActivityLogService>();

        return services;
    }
}
