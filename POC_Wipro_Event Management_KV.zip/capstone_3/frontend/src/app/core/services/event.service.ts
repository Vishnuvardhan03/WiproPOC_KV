import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { API_BASE_URL } from './api-config';
import {
  CreateEventRequest,
  EventResponse,
  OrganizerEventsDashboard,
  UpdateEventRequest
} from '../models/event.models';
import { ApiCacheService } from './api-cache.service';

@Injectable({ providedIn: 'root' })
export class EventService {
  constructor(
    private readonly http: HttpClient,
    private readonly cache: ApiCacheService
  ) {}

  search(query?: string): Observable<EventResponse[]> {
    let params = new HttpParams();
    if (query) {
      params = params.set('query', query);
    }

    const key = `events:search:${query ?? ''}`;
    return this.cache.getOrSet(key, () => this.http.get<EventResponse[]>(`${API_BASE_URL}/events/search`, { params }), 15000);
  }

  create(request: CreateEventRequest): Observable<EventResponse> {
    return this.http.post<EventResponse>(`${API_BASE_URL}/events`, request).pipe(
      tap(() => this.cache.invalidateByPrefix('events:search:'))
    );
  }

  update(eventId: string, request: UpdateEventRequest): Observable<EventResponse> {
    return this.http.put<EventResponse>(`${API_BASE_URL}/events/${eventId}`, request).pipe(
      tap(() => this.cache.invalidateByPrefix('events:search:'))
    );
  }

  delete(eventId: string): Observable<void> {
    return this.http.delete<void>(`${API_BASE_URL}/events/${eventId}`).pipe(
      tap(() => this.cache.invalidateByPrefix('events:search:'))
    );
  }

  getOrganizerDashboard(): Observable<OrganizerEventsDashboard> {
    return this.http.get<OrganizerEventsDashboard>(`${API_BASE_URL}/events/organizer/dashboard`);
  }
}
