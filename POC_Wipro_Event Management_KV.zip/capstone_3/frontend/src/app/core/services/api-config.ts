const apiHost = typeof window !== 'undefined' ? window.location.hostname : 'localhost';

export const API_ORIGIN = `http://${apiHost}:5274`;
export const API_BASE_URL = `${API_ORIGIN}/api`;
