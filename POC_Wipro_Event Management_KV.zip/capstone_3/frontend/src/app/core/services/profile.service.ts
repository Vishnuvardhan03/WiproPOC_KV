import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { API_BASE_URL } from './api-config';
import { RequestRoleChangeRequest, UpdateProfileRequest, UserProfile } from '../models/profile.models';
import { ApiCacheService } from './api-cache.service';

@Injectable({ providedIn: 'root' })
export class ProfileService {
  constructor(
    private readonly http: HttpClient,
    private readonly cache: ApiCacheService
  ) {}

  getProfile(): Observable<UserProfile> {
    return this.cache.getOrSet('profile:me', () => this.http.get<UserProfile>(`${API_BASE_URL}/profile`), 30000);
  }

  updateProfile(request: UpdateProfileRequest): Observable<UserProfile> {
    return this.http.put<UserProfile>(`${API_BASE_URL}/profile`, request).pipe(
      tap(() => this.cache.invalidate('profile:me'))
    );
  }

  requestRoleChange(request: RequestRoleChangeRequest): Observable<void> {
    return this.http.post<void>(`${API_BASE_URL}/profile/role-request`, request);
  }
}
