import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { API_BASE_URL } from './api-config';
import { BookingResponse } from '../models/booking.models';
import { EventResponse } from '../models/event.models';
import {
  ActivityLog,
  EventChangeRequest,
  ReportSummary,
  ReviewRequest,
  RoleChangeRequest,
  UpdateUserRoleRequest,
  UserSummary
} from '../models/admin.models';
import { ApiCacheService } from './api-cache.service';

@Injectable({ providedIn: 'root' })
export class AdminService {
  constructor(
    private readonly http: HttpClient,
    private readonly cache: ApiCacheService
  ) {}

  getUsers(): Observable<UserSummary[]> {
    return this.cache.getOrSet('admin:users', () => this.http.get<UserSummary[]>(`${API_BASE_URL}/admin/users`), 10000);
  }

  updateUserRole(userId: string, request: UpdateUserRoleRequest): Observable<void> {
    return this.http.patch<void>(`${API_BASE_URL}/admin/users/${userId}/role`, request).pipe(
      tap(() => {
        this.cache.invalidateByPrefix('admin:users');
        this.cache.invalidateByPrefix('admin:reports');
      })
    );
  }

  getEvents(): Observable<EventResponse[]> {
    return this.cache.getOrSet('admin:events', () => this.http.get<EventResponse[]>(`${API_BASE_URL}/admin/events`), 10000);
  }

  deleteEvent(eventId: string): Observable<void> {
    return this.http.delete<void>(`${API_BASE_URL}/admin/events/${eventId}`).pipe(
      tap(() => {
        this.cache.invalidateByPrefix('admin:events');
        this.cache.invalidateByPrefix('admin:reports');
      })
    );
  }

  getBookings(): Observable<BookingResponse[]> {
    return this.http.get<BookingResponse[]>(`${API_BASE_URL}/admin/bookings`);
  }

  getBookingsByEvent(eventId: string): Observable<BookingResponse[]> {
    return this.http.get<BookingResponse[]>(`${API_BASE_URL}/admin/events/${eventId}/bookings`);
  }

  approveBooking(bookingId: string): Observable<void> {
    return this.http.patch<void>(`${API_BASE_URL}/admin/bookings/${bookingId}/approve`, {}).pipe(
      tap(() => {
        this.cache.invalidateByPrefix('admin:bookings');
        this.cache.invalidateByPrefix('admin:reports');
        this.cache.invalidateByPrefix('bookings:history');
        this.cache.invalidateByPrefix('events:search:');
      })
    );
  }

  declineBooking(bookingId: string): Observable<void> {
    return this.http.patch<void>(`${API_BASE_URL}/admin/bookings/${bookingId}/decline`, {}).pipe(
      tap(() => {
        this.cache.invalidateByPrefix('admin:bookings');
        this.cache.invalidateByPrefix('admin:reports');
        this.cache.invalidateByPrefix('bookings:history');
        this.cache.invalidateByPrefix('events:search:');
      })
    );
  }

  cancelBooking(bookingId: string): Observable<void> {
    return this.http.delete<void>(`${API_BASE_URL}/admin/bookings/${bookingId}`).pipe(
      tap(() => {
        this.cache.invalidateByPrefix('admin:bookings');
        this.cache.invalidateByPrefix('admin:reports');
        this.cache.invalidateByPrefix('bookings:history');
        this.cache.invalidateByPrefix('events:search:');
      })
    );
  }

  getReports(): Observable<ReportSummary> {
    return this.http.get<ReportSummary>(`${API_BASE_URL}/admin/reports`);
  }

  getPendingRoleRequests(): Observable<RoleChangeRequest[]> {
    return this.http.get<RoleChangeRequest[]>(`${API_BASE_URL}/admin/role-requests`);
  }

  approveRoleRequest(requestId: string, request: ReviewRequest): Observable<void> {
    return this.http.patch<void>(`${API_BASE_URL}/admin/role-requests/${requestId}/approve`, request);
  }

  rejectRoleRequest(requestId: string, request: ReviewRequest): Observable<void> {
    return this.http.patch<void>(`${API_BASE_URL}/admin/role-requests/${requestId}/reject`, request);
  }

  getPendingEventChangeRequests(): Observable<EventChangeRequest[]> {
    return this.http.get<EventChangeRequest[]>(`${API_BASE_URL}/admin/event-change-requests`);
  }

  approveEventChangeRequest(requestId: string, request: ReviewRequest): Observable<void> {
    return this.http.patch<void>(`${API_BASE_URL}/admin/event-change-requests/${requestId}/approve`, request);
  }

  rejectEventChangeRequest(requestId: string, request: ReviewRequest): Observable<void> {
    return this.http.patch<void>(`${API_BASE_URL}/admin/event-change-requests/${requestId}/reject`, request);
  }

  getActivityLogs(count = 50): Observable<ActivityLog[]> {
    return this.http.get<ActivityLog[]>(`${API_BASE_URL}/admin/activity-logs`, {
      params: { count }
    });
  }
}
