import { Injectable, computed, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';
import { API_BASE_URL, API_ORIGIN } from './api-config';
import { AppNotification } from '../models/notification.models';
import { AuthService } from './auth.service';
import * as signalR from '@microsoft/signalr';

@Injectable({ providedIn: 'root' })
export class NotificationService {
  private hubConnection: signalR.HubConnection | null = null;
  private readonly notificationsSignal = signal<AppNotification[]>([]);
  private readonly lastErrorSignal = signal<string>('');
  private readonly connectedSignal = signal(false);

  readonly notifications = computed(() => this.notificationsSignal());
  readonly unreadCount = computed(() => this.notificationsSignal().filter((n) => !n.isRead).length);
  readonly isConnected = computed(() => this.connectedSignal());
  readonly lastError = computed(() => this.lastErrorSignal());

  readonly incoming$ = new Subject<AppNotification>();

  constructor(
    private readonly http: HttpClient,
    private readonly authService: AuthService
  ) {}

  load(): Observable<AppNotification[]> {
    return new Observable<AppNotification[]>((observer) => {
      this.http.get<AppNotification[]>(`${API_BASE_URL}/notifications`).subscribe({
        next: (items) => {
          this.notificationsSignal.set(items);
          observer.next(items);
          observer.complete();
        },
        error: (err) => {
          this.lastErrorSignal.set(err?.error?.error ?? err?.message ?? 'Failed to load notifications.');
          observer.error(err);
        }
      });
    });
  }

  markAsRead(notificationId: string): Observable<void> {
    return new Observable<void>((observer) => {
      this.http.patch<void>(`${API_BASE_URL}/notifications/${notificationId}/read`, {}).subscribe({
        next: () => {
          const updated = this.notificationsSignal().map((n) =>
            n.id === notificationId ? { ...n, isRead: true } : n
          );
          this.notificationsSignal.set(updated);
          observer.next();
          observer.complete();
        },
        error: (err) => observer.error(err)
      });
    });
  }

  async connect(): Promise<void> {
    const session = this.authService.session();
    if (!session?.token) {
      return;
    }

    if (this.hubConnection) {
      return;
    }

    this.hubConnection = new signalR.HubConnectionBuilder()
      .withUrl(`${API_ORIGIN}/hubs/notifications`, {
        accessTokenFactory: () => session.token
      })
      .withAutomaticReconnect()
      .build();

    this.hubConnection.on('notification', (payload: AppNotification) => {
      this.notificationsSignal.update((current) => [payload, ...current]);
      this.incoming$.next(payload);
    });

    this.hubConnection.onreconnected(() => {
      this.connectedSignal.set(true);
      this.load().subscribe({ error: () => undefined });
    });

    this.hubConnection.onclose(() => {
      this.connectedSignal.set(false);
    });

    try {
      await this.hubConnection.start();
      this.connectedSignal.set(true);
    } catch (err: any) {
      this.lastErrorSignal.set(err?.message ?? 'Failed to connect to notification hub.');
      this.connectedSignal.set(false);
    }
  }

  async disconnect(): Promise<void> {
    if (!this.hubConnection) {
      return;
    }

    await this.hubConnection.stop();
    this.hubConnection = null;
    this.connectedSignal.set(false);
  }
}
