import { Injectable } from '@angular/core';
import { AuthResponse } from '../models/auth.models';

const AUTH_KEY = 'ems_auth';

@Injectable({ providedIn: 'root' })
export class TokenStorageService {
  saveSession(session: AuthResponse): void {
    localStorage.setItem(AUTH_KEY, JSON.stringify(session));
    console.log('TOKEN SAVED', { key: AUTH_KEY, userId: session.userId, role: session.role });
  }

  getSession(): AuthResponse | null {
    const raw = localStorage.getItem(AUTH_KEY);
    if (!raw) {
      return null;
    }

    try {
      return JSON.parse(raw) as AuthResponse;
    } catch {
      localStorage.removeItem(AUTH_KEY);
      return null;
    }
  }

  clear(): void {
    localStorage.removeItem(AUTH_KEY);
  }

  getToken(): string | null {
    return this.getSession()?.token ?? null;
  }
}
