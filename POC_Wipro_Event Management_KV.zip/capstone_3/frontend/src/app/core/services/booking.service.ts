import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { API_BASE_URL } from './api-config';
import { BookEventRequest, BookingResponse, CheckInRequest } from '../models/booking.models';
import { ApiCacheService } from './api-cache.service';

@Injectable({ providedIn: 'root' })
export class BookingService {
  constructor(
    private readonly http: HttpClient,
    private readonly cache: ApiCacheService
  ) {}

  book(request: BookEventRequest): Observable<BookingResponse> {
    return this.http.post<BookingResponse>(`${API_BASE_URL}/bookings`, request).pipe(
      tap(() => {
        this.cache.invalidateByPrefix('events:search:');
        this.cache.invalidateByPrefix('bookings:history');
        this.cache.invalidateByPrefix('admin:bookings');
        this.cache.invalidateByPrefix('admin:reports');
      })
    );
  }

  cancel(bookingId: string): Observable<void> {
    return this.http.delete<void>(`${API_BASE_URL}/bookings/${bookingId}`).pipe(
      tap(() => {
        this.cache.invalidateByPrefix('events:search:');
        this.cache.invalidateByPrefix('bookings:history');
        this.cache.invalidateByPrefix('admin:bookings');
        this.cache.invalidateByPrefix('admin:reports');
      })
    );
  }

  history(): Observable<BookingResponse[]> {
    return this.cache.getOrSet(
      'bookings:history',
      () => this.http.get<BookingResponse[]>(`${API_BASE_URL}/bookings/history`),
      10000
    );
  }

  checkIn(request: CheckInRequest): Observable<BookingResponse> {
    return this.http.post<BookingResponse>(`${API_BASE_URL}/bookings/check-in`, request).pipe(
      tap(() => {
        this.cache.invalidateByPrefix('bookings:history');
        this.cache.invalidateByPrefix('admin:bookings');
        this.cache.invalidateByPrefix('admin:reports');
      })
    );
  }
}
