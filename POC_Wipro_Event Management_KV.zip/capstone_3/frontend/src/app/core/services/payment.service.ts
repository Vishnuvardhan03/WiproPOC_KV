import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { API_BASE_URL } from './api-config';
import {
  CompletePaymentRequest,
  CreatePaymentOrderRequest,
  PaymentResponse
} from '../models/payment.models';
import { ApiCacheService } from './api-cache.service';

@Injectable({ providedIn: 'root' })
export class PaymentService {
  constructor(
    private readonly http: HttpClient,
    private readonly cache: ApiCacheService
  ) {}

  createOrder(request: CreatePaymentOrderRequest): Observable<PaymentResponse> {
    return this.http.post<PaymentResponse>(`${API_BASE_URL}/payments/order`, request);
  }

  complete(request: CompletePaymentRequest): Observable<PaymentResponse> {
    return this.http.post<PaymentResponse>(`${API_BASE_URL}/payments/complete`, request).pipe(
      tap(() => {
        this.cache.invalidateByPrefix('bookings:history');
        this.cache.invalidateByPrefix('admin:bookings');
        this.cache.invalidateByPrefix('admin:reports');
      })
    );
  }
}
