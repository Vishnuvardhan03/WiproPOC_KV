import { Injectable, computed, inject, signal } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError, TimeoutError } from 'rxjs';
import { catchError, map, tap, timeout } from 'rxjs/operators';
import { AuthResponse, LoginRequest, RegisterRequest } from '../models/auth.models';
import { API_BASE_URL, API_ORIGIN } from './api-config';
import { TokenStorageService } from './token-storage.service';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private static readonly authTimeoutMs = 10000;

  private readonly http = inject(HttpClient);
  private readonly storage = inject(TokenStorageService);

  private readonly sessionSignal = signal<AuthResponse | null>(this.storage.getSession());
  private readonly initializedSignal = signal(false);

  readonly session = computed(() => this.sessionSignal());
  readonly isAuthenticated = computed(() => !!this.sessionSignal()?.token);
  readonly userRole = computed(() => this.sessionSignal()?.role ?? null);
  readonly isInitialized = computed(() => this.initializedSignal());

  constructor() {
    this.initializedSignal.set(true);
  }

  register(request: RegisterRequest): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${API_BASE_URL}/auth/register`, request, { observe: 'response' }).pipe(
      timeout(AuthService.authTimeoutMs),
      tap((response) => console.log('LOGIN RESPONSE', { status: response.status, payload: response.body })),
      map((response) => this.extractAndSetSession(response)),
      catchError((error) => this.handleAuthError(error))
    );
  }

  login(request: LoginRequest): Observable<AuthResponse> {
    console.log('LOGIN START', { email: request.email });
    return this.http.post<AuthResponse>(`${API_BASE_URL}/auth/login`, request, { observe: 'response' }).pipe(
      timeout(AuthService.authTimeoutMs),
      tap((response) => console.log('LOGIN RESPONSE', { status: response.status, payload: response.body })),
      map((response) => this.extractAndSetSession(response)),
      catchError((error) => this.handleAuthError(error))
    );
  }

  logout(): void {
    this.storage.clear();
    this.sessionSignal.set(null);
  }

  hasRole(expectedRoles: string[]): boolean {
    const role = this.userRole();
    return !!role && expectedRoles.includes(role);
  }

  private setSession(response: AuthResponse): void {
    this.storage.saveSession(response);
    this.sessionSignal.set(response);
    console.log('AUTH STATE UPDATED', { userId: response.userId, role: response.role, initialized: this.isInitialized() });
  }

  private extractAndSetSession(response: HttpResponse<AuthResponse>): AuthResponse {
    if (!response.body) {
      throw new Error('Authentication response payload is empty.');
    }

    this.setSession(response.body);
    return response.body;
  }

  private handleAuthError(error: unknown): Observable<never> {
    if (error instanceof TimeoutError) {
      return throwError(() => new Error(`The authentication request timed out. Verify the API is running on ${API_ORIGIN}.`));
    }

    if (error instanceof HttpErrorResponse && error.status === 0) {
      return throwError(() => new Error(`Cannot reach the API at ${API_ORIGIN}. Start the backend and try again.`));
    }

    if (error instanceof HttpErrorResponse) {
      if (error.status === 401) {
        return throwError(() => new Error('Invalid email or password.'));
      }

      if (error.status >= 500) {
        return throwError(() => new Error('Server error. Please try again in a moment.'));
      }
    }

    return throwError(() => error instanceof Error ? error : new Error('Authentication failed.'));
  }
}
