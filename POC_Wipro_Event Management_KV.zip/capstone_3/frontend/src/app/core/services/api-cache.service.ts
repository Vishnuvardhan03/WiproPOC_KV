import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { shareReplay } from 'rxjs/operators';

type CacheEntry<T> = {
  expiresAt: number;
  stream: Observable<T>;
};

@Injectable({ providedIn: 'root' })
export class ApiCacheService {
  private readonly cache = new Map<string, CacheEntry<unknown>>();

  getOrSet<T>(key: string, factory: () => Observable<T>, ttlMs = 15000): Observable<T> {
    const now = Date.now();
    const existing = this.cache.get(key) as CacheEntry<T> | undefined;

    if (existing && existing.expiresAt > now) {
      return existing.stream;
    }

    const stream = factory().pipe(shareReplay({ bufferSize: 1, refCount: false }));
    this.cache.set(key, { expiresAt: now + ttlMs, stream });
    return stream;
  }

  invalidate(key: string): void {
    this.cache.delete(key);
  }

  invalidateByPrefix(prefix: string): void {
    for (const key of this.cache.keys()) {
      if (key.startsWith(prefix)) {
        this.cache.delete(key);
      }
    }
  }

  clear(): void {
    this.cache.clear();
  }
}
