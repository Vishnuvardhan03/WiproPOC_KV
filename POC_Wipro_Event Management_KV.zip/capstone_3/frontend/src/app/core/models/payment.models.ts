export interface CreatePaymentOrderRequest {
  bookingId: string;
}

export interface CompletePaymentRequest {
  providerOrderId: string;
  providerPaymentId: string;
  success: boolean;
  failureReason?: string;
}

export interface PaymentResponse {
  paymentId: string;
  bookingId: string;
  amountInRupees: number;
  currency: string;
  providerOrderId: string;
  providerPaymentId: string;
  status: string;
  createdAtUtc: string;
  paidAtUtc?: string | null;
}
