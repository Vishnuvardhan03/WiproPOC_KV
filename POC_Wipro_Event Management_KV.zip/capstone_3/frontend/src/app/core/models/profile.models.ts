export interface UserProfile {
  id: string;
  fullName: string;
  email: string;
  role: string;
}

export interface UpdateProfileRequest {
  fullName: string;
}

export interface RequestRoleChangeRequest {
  role: 'Organizer' | 'Admin';
}
