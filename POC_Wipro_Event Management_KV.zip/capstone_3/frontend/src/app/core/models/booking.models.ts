export interface BookEventRequest {
  eventId: string;
}

export interface BookingResponse {
  bookingId: string;
  eventId: string;
  attendeeId: string;
  attendeeName: string;
  attendeeEmail: string;
  eventTitle: string;
  eventStartDateUtc: string;
  eventEndDateUtc: string;
  ticketNumber: string;
  status: string;
  createdAtUtc: string;
  checkedInAtUtc?: string | null;
}

export interface CheckInRequest {
  ticketNumber: string;
}
