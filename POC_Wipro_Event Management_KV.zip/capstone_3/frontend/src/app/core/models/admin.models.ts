export interface UserSummary {
  id: string;
  fullName: string;
  email: string;
  role: string;
}

export interface ReportSummary {
  totalUsers: number;
  totalAdmins: number;
  totalOrganizers: number;
  totalAttendees: number;
  totalEvents: number;
  upcomingEvents: number;
  completedEvents: number;
  totalBookings: number;
  cancelledBookings: number;
  checkedInAttendees: number;
  activeEvents: number;
  totalCapacity: number;
  occupancyPercentage: number;
}

export interface UpdateUserRoleRequest {
  role: string;
}

export interface RoleChangeRequest {
  requestId: string;
  userId: string;
  userName: string;
  userEmail: string;
  currentRole: string;
  requestedRole: string;
  status: string;
  adminComment?: string | null;
  createdAtUtc: string;
}

export interface EventChangeRequest {
  requestId: string;
  eventId: string;
  eventTitle: string;
  requestedByOrganizerId: string;
  requestedByOrganizerName: string;
  status: string;
  adminComment?: string | null;
  createdAtUtc: string;
  proposedTitle: string;
  proposedDescription: string;
  proposedLocation: string;
  proposedStartDateUtc: string;
  proposedEndDateUtc: string;
  proposedCapacity: number;
  proposedPriceInRupees: number;
}

export interface ActivityLog {
  id: string;
  actorUserId?: string | null;
  actorUserName: string;
  action: string;
  entityType: string;
  entityId?: string | null;
  metadata: string;
  createdAtUtc: string;
}

export interface ReviewRequest {
  comment?: string;
}
