export interface AppNotification {
  id: string;
  title: string;
  message: string;
  isRead: boolean;
  createdAtUtc: string;
}
