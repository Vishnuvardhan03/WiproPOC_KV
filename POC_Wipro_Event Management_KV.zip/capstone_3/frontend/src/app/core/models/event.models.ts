export interface EventResponse {
  id: string;
  title: string;
  description: string;
  location: string;
  startDateUtc: string;
  endDateUtc: string;
  capacity: number;
  priceInRupees: number;
  confirmedBookings: number;
  organizerId: string;
  organizerName: string;
}

export interface CreateEventRequest {
  title: string;
  description: string;
  location: string;
  startDateUtc: string;
  endDateUtc: string;
  capacity: number;
  priceInRupees: number;
}

export type UpdateEventRequest = CreateEventRequest;

export interface EventAttendee {
  attendeeId: string;
  fullName: string;
  email: string;
  bookingStatus: string;
  ticketNumber: string;
  checkedInAtUtc?: string | null;
}

export interface OrganizerEventWithAttendees {
  eventId: string;
  title: string;
  location: string;
  startDateUtc: string;
  endDateUtc: string;
  capacity: number;
  priceInRupees: number;
  attendees: EventAttendee[];
}

export interface OrganizerEventsDashboard {
  upcomingEvents: OrganizerEventWithAttendees[];
  pastEvents: OrganizerEventWithAttendees[];
}
