export interface RegisterRequest {
  fullName: string;
  email: string;
  password: string;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface AuthResponse {
  token: string;
  expiresAtUtc: string;
  userId: string;
  email: string;
  fullName: string;
  role: 'Admin' | 'Organizer' | 'Attendee';
}
