import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { forkJoin } from 'rxjs';
import { finalize } from 'rxjs/operators';
import { AdminService } from '../../../core/services/admin.service';
import {
  ActivityLog,
  EventChangeRequest,
  ReportSummary,
  RoleChangeRequest,
  UserSummary
} from '../../../core/models/admin.models';
import { BookingService } from '../../../core/services/booking.service';
import { BookingResponse } from '../../../core/models/booking.models';
import { EventResponse } from '../../../core/models/event.models';

@Component({
  selector: 'app-admin-dashboard-page',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="container py-4 py-md-5">
      <section class="surface-card p-4 p-md-5 mb-4">
        <h2 class="mb-1">Admin Dashboard</h2>
        <p class="muted mb-0">Monitor system activity, user roles, and bookings in real time.</p>
      </section>

      <div *ngIf="loading" class="text-muted mb-3">
        <span class="spinner-border spinner-border-sm me-2"></span>
        Loading dashboard...
      </div>

      <div *ngIf="error" class="alert alert-danger">{{ error }}</div>

      <div class="surface-card p-4 mb-4" *ngIf="pendingBookings.length > 0">
        <div class="d-flex justify-content-between align-items-center gap-3 mb-3">
          <div>
            <h5 class="mb-1">Pending Booking Requests</h5>
            <p class="muted mb-0">Approve attendee requests before they become confirmed bookings.</p>
          </div>
          <span class="badge bg-warning text-dark">{{ pendingBookings.length }} pending</span>
        </div>

        <div class="table-responsive">
          <table class="table align-middle mb-0">
            <thead>
              <tr>
                <th>Attendee</th>
                <th>Event</th>
                <th>Requested</th>
                <th>Ticket</th>
                <th style="width:180px"></th>
              </tr>
            </thead>
            <tbody>
              <tr *ngFor="let booking of pendingBookings">
                <td>
                  <div class="fw-semibold">{{ booking.attendeeName }}</div>
                  <small class="text-muted">{{ booking.attendeeEmail }}</small>
                </td>
                <td>{{ booking.eventTitle }}</td>
                <td>{{ booking.createdAtUtc | date:'medium' }}</td>
                <td><code class="small">{{ booking.ticketNumber }}</code></td>
                <td>
                  <button class="btn btn-success btn-sm me-2" (click)="approveBooking(booking.bookingId)">Accept</button>
                  <button class="btn btn-outline-danger btn-sm" (click)="declineBooking(booking.bookingId)">Decline</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div class="surface-card p-4 mb-4" *ngIf="roleRequests.length > 0">
        <h5 class="mb-3">Pending Role Requests</h5>
        <div class="table-responsive">
          <table class="table align-middle mb-0">
            <thead>
              <tr>
                <th>User</th>
                <th>Current Role</th>
                <th>Requested Role</th>
                <th>Requested At</th>
                <th style="width:200px"></th>
              </tr>
            </thead>
            <tbody>
              <tr *ngFor="let request of roleRequests">
                <td>{{ request.userName }}<br /><small class="text-muted">{{ request.userEmail }}</small></td>
                <td>{{ request.currentRole }}</td>
                <td>{{ request.requestedRole }}</td>
                <td>{{ request.createdAtUtc | date:'medium' }}</td>
                <td>
                  <button class="btn btn-success btn-sm me-2" (click)="approveRoleRequest(request.requestId)">Approve</button>
                  <button class="btn btn-outline-danger btn-sm" (click)="rejectRoleRequest(request.requestId)">Reject</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div class="surface-card p-4 mb-4" *ngIf="eventChangeRequests.length > 0">
        <h5 class="mb-3">Pending Event Change Requests</h5>
        <div class="table-responsive">
          <table class="table align-middle mb-0">
            <thead>
              <tr>
                <th>Event</th>
                <th>Organizer</th>
                <th>Proposed</th>
                <th>Requested At</th>
                <th style="width:200px"></th>
              </tr>
            </thead>
            <tbody>
              <tr *ngFor="let request of eventChangeRequests">
                <td>{{ request.eventTitle }}</td>
                <td>{{ request.requestedByOrganizerName }}</td>
                <td>
                  <div class="small">Title: {{ request.proposedTitle }}</div>
                  <div class="small">Location: {{ request.proposedLocation }}</div>
                  <div class="small">Capacity: {{ request.proposedCapacity }} | INR {{ request.proposedPriceInRupees }}</div>
                </td>
                <td>{{ request.createdAtUtc | date:'medium' }}</td>
                <td>
                  <button class="btn btn-success btn-sm me-2" (click)="approveEventChangeRequest(request.requestId)">Approve</button>
                  <button class="btn btn-outline-danger btn-sm" (click)="rejectEventChangeRequest(request.requestId)">Reject</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div class="surface-card p-4 mb-4">
        <h5 class="mb-2">Users Registered Per Event</h5>
        <div class="row g-2 align-items-center mb-3" style="max-width:640px">
          <div class="col-md-8">
            <select class="form-select" [(ngModel)]="selectedEventId" (ngModelChange)="onSelectedEventChange()">
              <option [ngValue]="''">Select an event</option>
              <option *ngFor="let event of events" [ngValue]="event.id">{{ event.title }}</option>
            </select>
          </div>
          <div class="col-md-4">
            <button class="btn btn-outline-primary w-100" (click)="loadSelectedEventBookings()" [disabled]="!selectedEventId">Load Registrations</button>
          </div>
        </div>

        <div class="table-responsive" *ngIf="selectedEventBookings.length > 0">
          <table class="table align-middle mb-0">
            <thead>
              <tr>
                <th>Attendee</th>
                <th>Email</th>
                <th>Status</th>
                <th>Ticket</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngFor="let booking of selectedEventBookings">
                <td>{{ booking.attendeeName }}</td>
                <td>{{ booking.attendeeEmail }}</td>
                <td>{{ booking.status }}</td>
                <td><code>{{ booking.ticketNumber }}</code></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Report tiles -->
      <div class="row g-3 mb-4" *ngIf="report">
        <div class="col-6 col-md-3" *ngFor="let tile of tiles">
          <div class="surface-card p-3 h-100">
            <div class="muted mb-1">{{ tile.label }}</div>
            <h3 class="mb-0 fw-bold">{{ tile.value }}</h3>
          </div>
        </div>
      </div>

      <!-- Ticket check-in -->
      <div class="surface-card p-4 mb-4">
        <h5 class="mb-3">Ticket Check-In</h5>
        <div class="input-group" style="max-width:520px">
          <input class="form-control" placeholder="Ticket number e.g. TCK-20260703-..." [(ngModel)]="ticketNumber" />
          <button class="btn btn-primary" (click)="checkIn()">Check In</button>
        </div>
        <div class="text-success mt-2" *ngIf="checkInMessage">{{ checkInMessage }}</div>
        <div class="text-danger mt-2" *ngIf="checkInError">{{ checkInError }}</div>
      </div>

      <!-- Users management -->
      <h5 class="mb-2">Users
        <span class="badge bg-secondary ms-2">{{ users.length }}</span>
      </h5>
      <div class="surface-card p-3 table-responsive mb-4">
        <table class="table table-hover align-middle mb-0">
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Role</th>
              <th style="width:160px">Change Role</th>
            </tr>
          </thead>
          <tbody>
            <tr *ngFor="let user of users">
              <td>{{ user.fullName }}</td>
              <td>{{ user.email }}</td>
              <td>
                <span class="badge"
                  [class.bg-danger]="user.role === 'Admin'"
                  [class.bg-primary]="user.role === 'Organizer'"
                  [class.bg-success]="user.role === 'Attendee'">
                  {{ user.role }}
                </span>
              </td>
              <td>
                <select class="form-select form-select-sm"
                  [ngModel]="user.role"
                  (ngModelChange)="changeRole(user, $event)">
                  <option value="Admin">Admin</option>
                  <option value="Organizer">Organizer</option>
                  <option value="Attendee">Attendee</option>
                </select>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- All bookings -->
      <h5 class="mb-2">All Bookings
        <span class="badge bg-secondary ms-2">{{ bookings.length }}</span>
      </h5>
      <div class="surface-card p-3 table-responsive">
        <table class="table table-hover align-middle mb-0">
          <thead>
            <tr>
              <th>Attendee</th>
              <th>Event</th>
              <th>Ticket</th>
              <th>Status</th>
              <th>Checked In</th>
              <th style="width:180px"></th>
            </tr>
          </thead>
          <tbody>
            <tr *ngFor="let booking of bookings">
              <td>
                <div class="fw-semibold">{{ booking.attendeeName }}</div>
                <small class="text-muted">{{ booking.attendeeEmail }}</small>
              </td>
              <td>{{ booking.eventTitle }}</td>
              <td><code class="small">{{ booking.ticketNumber }}</code></td>
              <td>
                <span class="badge"
                  [class.bg-warning]="booking.status === 'Pending'"
                  [class.bg-success]="booking.status === 'Booked'"
                  [class.bg-danger]="booking.status === 'Declined'"
                  [class.bg-secondary]="booking.status === 'Cancelled'">
                  {{ booking.status }}
                </span>
              </td>
              <td>{{ booking.checkedInAtUtc ? (booking.checkedInAtUtc | date:'medium') : '-' }}</td>
              <td>
                <button class="btn btn-outline-success btn-sm me-2"
                  *ngIf="booking.status === 'Pending'"
                  (click)="approveBooking(booking.bookingId)">Accept</button>
                <button class="btn btn-outline-danger btn-sm me-2"
                  *ngIf="booking.status === 'Pending'"
                  (click)="declineBooking(booking.bookingId)">Decline</button>
                <button class="btn btn-outline-danger btn-sm"
                  *ngIf="booking.status === 'Booked'"
                  (click)="cancelBooking(booking.bookingId)">Cancel</button>
              </td>
            </tr>
            <tr *ngIf="bookings.length === 0">
              <td colspan="6" class="text-center text-muted">No bookings yet.</td>
            </tr>
          </tbody>
        </table>
      </div>

      <div class="surface-card p-4 mt-4">
        <h5 class="mb-2">Recent Activity Logs</h5>
        <div class="table-responsive">
          <table class="table align-middle mb-0">
            <thead>
              <tr>
                <th>Time</th>
                <th>Actor</th>
                <th>Action</th>
                <th>Entity</th>
                <th>Metadata</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngFor="let log of activityLogs">
                <td>{{ log.createdAtUtc | date:'short' }}</td>
                <td>{{ log.actorUserName || 'System' }}</td>
                <td>{{ log.action }}</td>
                <td>{{ log.entityType }}</td>
                <td><code class="small">{{ log.metadata }}</code></td>
              </tr>
              <tr *ngIf="activityLogs.length === 0">
                <td colspan="5" class="text-muted text-center">No recent activity.</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class AdminDashboardPageComponent implements OnInit {
  users: UserSummary[] = [];
  events: EventResponse[] = [];
  bookings: BookingResponse[] = [];
  selectedEventBookings: BookingResponse[] = [];
  report: ReportSummary | null = null;
  roleRequests: RoleChangeRequest[] = [];
  eventChangeRequests: EventChangeRequest[] = [];
  activityLogs: ActivityLog[] = [];
  selectedEventId = '';
  loading = false;
  error = '';
  ticketNumber = '';
  checkInMessage = '';
  checkInError = '';

  constructor(
    private readonly adminService: AdminService,
    private readonly bookingService: BookingService
  ) {}

  get pendingBookings(): BookingResponse[] {
    return this.bookings.filter((booking) => booking.status === 'Pending');
  }

  get tiles(): Array<{ label: string; value: number }> {
    if (!this.report) return [];
    return [
      { label: 'Total Users',       value: this.report.totalUsers },
      { label: 'Admins',            value: this.report.totalAdmins },
      { label: 'Organizers',        value: this.report.totalOrganizers },
      { label: 'Attendees',         value: this.report.totalAttendees },
      { label: 'Total Events',      value: this.report.totalEvents },
      { label: 'Upcoming Events',   value: this.report.upcomingEvents },
      { label: 'Completed Events',  value: this.report.completedEvents },
      { label: 'Active Events',     value: this.report.activeEvents },
      { label: 'Total Bookings',    value: this.report.totalBookings },
      { label: 'Cancelled',         value: this.report.cancelledBookings },
      { label: 'Checked In',        value: this.report.checkedInAttendees },
      { label: 'Total Capacity',    value: this.report.totalCapacity },
      { label: 'Occupancy %',       value: this.report.occupancyPercentage }
    ];
  }

  ngOnInit(): void {
    this.loadDashboard();
  }

  checkIn(): void {
    this.checkInMessage = '';
    this.checkInError = '';
    this.bookingService.checkIn({ ticketNumber: this.ticketNumber }).subscribe({
      next: (booking) => {
        this.checkInMessage = `Checked in: ${booking.eventTitle} - ticket ${booking.ticketNumber}`;
        this.ticketNumber = '';
        this.loadDashboard();
      },
      error: (err) => {
        this.checkInError = err?.error?.error ?? 'Check-in failed.';
      }
    });
  }

  cancelBooking(bookingId: string): void {
    this.adminService.cancelBooking(bookingId).subscribe({
      next: () => this.loadDashboard(),
      error: (err) => {
        this.error = err?.error?.error ?? err?.message ?? 'Failed to cancel booking.';
      }
    });
  }

  approveBooking(bookingId: string): void {
    this.adminService.approveBooking(bookingId).subscribe({
      next: () => this.loadDashboard(),
      error: (err) => {
        this.error = err?.error?.error ?? err?.message ?? 'Failed to approve booking.';
      }
    });
  }

  declineBooking(bookingId: string): void {
    this.adminService.declineBooking(bookingId).subscribe({
      next: () => this.loadDashboard(),
      error: (err) => {
        this.error = err?.error?.error ?? err?.message ?? 'Failed to decline booking.';
      }
    });
  }

  approveRoleRequest(requestId: string): void {
    this.adminService.approveRoleRequest(requestId, {}).subscribe({
      next: () => this.loadDashboard(),
      error: (err) => (this.error = err?.error?.error ?? err?.message ?? 'Failed to approve role request.')
    });
  }

  rejectRoleRequest(requestId: string): void {
    this.adminService.rejectRoleRequest(requestId, {}).subscribe({
      next: () => this.loadDashboard(),
      error: (err) => (this.error = err?.error?.error ?? err?.message ?? 'Failed to reject role request.')
    });
  }

  approveEventChangeRequest(requestId: string): void {
    this.adminService.approveEventChangeRequest(requestId, {}).subscribe({
      next: () => this.loadDashboard(),
      error: (err) => (this.error = err?.error?.error ?? err?.message ?? 'Failed to approve event change request.')
    });
  }

  rejectEventChangeRequest(requestId: string): void {
    this.adminService.rejectEventChangeRequest(requestId, {}).subscribe({
      next: () => this.loadDashboard(),
      error: (err) => (this.error = err?.error?.error ?? err?.message ?? 'Failed to reject event change request.')
    });
  }

  onSelectedEventChange(): void {
    this.selectedEventBookings = [];
  }

  loadSelectedEventBookings(): void {
    if (!this.selectedEventId) {
      return;
    }

    this.adminService.getBookingsByEvent(this.selectedEventId).subscribe({
      next: (bookings) => {
        this.selectedEventBookings = bookings;
      },
      error: (err) => {
        this.error = err?.error?.error ?? err?.message ?? 'Failed to load event registrations.';
      }
    });
  }

  changeRole(user: UserSummary, newRole: string): void {
    if (newRole === user.role) return;
    this.adminService.updateUserRole(user.id, { role: newRole }).subscribe({
      next: () => {
        user.role = newRole;
      },
      error: (err) => {
        this.error = err?.error?.error ?? err?.message ?? 'Failed to update user role.';
      }
    });
  }

  private loadDashboard(): void {
    // Load all three in parallel to avoid cascading delays.
    console.log('DASHBOARD DATA FETCH START');
    this.loading = true;
    this.error = '';

    forkJoin({
      users: this.adminService.getUsers(),
      events: this.adminService.getEvents(),
      bookings: this.adminService.getBookings(),
      report: this.adminService.getReports(),
      roleRequests: this.adminService.getPendingRoleRequests(),
      eventChangeRequests: this.adminService.getPendingEventChangeRequests(),
      activityLogs: this.adminService.getActivityLogs(50)
    })
      .pipe(finalize(() => (this.loading = false)))
      .subscribe({
        next: ({ users, events, bookings, report, roleRequests, eventChangeRequests, activityLogs }) => {
          this.users = users;
          this.events = events;
          this.bookings = bookings;
          this.report = report;
          this.roleRequests = roleRequests;
          this.eventChangeRequests = eventChangeRequests;
          this.activityLogs = activityLogs;
          console.log('DASHBOARD DATA FETCH SUCCESS', {
            users: users.length,
            bookings: bookings.length,
            hasReport: !!report
          });
        },
        error: (err) => {
          this.error = err?.error?.error ?? err?.message ?? 'Failed to load admin dashboard.';
        }
      });
  }
}
