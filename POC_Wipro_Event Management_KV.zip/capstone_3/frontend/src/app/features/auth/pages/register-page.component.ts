import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { finalize } from 'rxjs/operators';
import { AuthService } from '../../../core/services/auth.service';
import { RegisterRequest } from '../../../core/models/auth.models';

@Component({
  selector: 'app-register-page',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  template: `
    <div class="container py-4 py-md-5">
      <div class="auth-shell">
        <section class="auth-hero">
          <span class="auth-badge">Get Started</span>
          <h1>Build premium event experiences in minutes.</h1>
          <p class="muted mb-4">
            Register as attendee first, then request Organizer or Admin role from your profile.
          </p>
          <ul class="muted ps-3 mb-0">
            <li class="mb-2">Fast onboarding and secure login</li>
            <li class="mb-2">Secure authentication with JWT</li>
            <li>Role requests and approvals handled by admins</li>
          </ul>
        </section>

        <section class="auth-form-wrap card card-body">
          <h2 class="mb-1">Create Account</h2>
          <p class="muted mb-4">Join the Event Management System.</p>
          <form [formGroup]="form" (ngSubmit)="submit()">
            <div class="mb-3">
              <label class="form-label fw-semibold">Full Name</label>
              <input class="form-control" formControlName="fullName" placeholder="Your full name" />
            </div>
            <div class="mb-3">
              <label class="form-label fw-semibold">Email</label>
              <input class="form-control" type="email" formControlName="email" placeholder="you@example.com" autocomplete="username" />
            </div>
            <div class="mb-3">
              <label class="form-label fw-semibold">Password</label>
              <input class="form-control" type="password" formControlName="password"
                placeholder="At least 8 characters" autocomplete="new-password" />
            </div>
            <button class="btn btn-success w-100" [disabled]="form.invalid || loading">
              <span *ngIf="loading" class="spinner-border spinner-border-sm me-2"></span>
              {{ loading ? 'Creating account...' : 'Create Account' }}
            </button>
            <div class="alert alert-danger mt-3 py-2 mb-0" *ngIf="error">{{ error }}</div>
            <p class="mt-3 mb-0 text-center muted">
              Already have an account? <a routerLink="/auth/login">Sign in</a>
            </p>
          </form>
        </section>
      </div>
    </div>
  `
})
export class RegisterPageComponent implements OnInit {
  private readonly fb = inject(FormBuilder);
  private readonly authService = inject(AuthService);
  private readonly router = inject(Router);

  loading = false;
  error = '';

  readonly form = this.fb.group({
    fullName: ['', [Validators.required, Validators.minLength(2)]],
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(8)]]
  });

  ngOnInit(): void {
    if (this.authService.isAuthenticated()) {
      this.router.navigateByUrl('/events');
    }
  }

  submit(): void {
    if (this.form.invalid) return;
    this.loading = true;
    this.error = '';

    this.authService
      .register(this.form.getRawValue() as RegisterRequest)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe({
      next: (response) => {
        const target = '/events';
        void this.router.navigateByUrl(target).catch(() => {
          this.error = 'Registration succeeded but navigation failed.';
        });
      },
      error: (err) => {
        this.error = err?.error?.error ?? err?.message ?? 'Registration failed. Try a different email.';
      }
    });
  }
}
