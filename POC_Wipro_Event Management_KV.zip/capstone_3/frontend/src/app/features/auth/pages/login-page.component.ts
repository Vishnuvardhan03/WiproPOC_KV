import { Component, OnInit, inject } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { finalize } from 'rxjs/operators';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-login-page',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  template: `
    <div class="container py-4 py-md-5">
      <div class="auth-shell">
        <section class="auth-hero">
          <span class="auth-badge">Premium Event Platform</span>
          <h1>Run events with clarity, speed, and confidence.</h1>
          <p class="muted mb-4">
            Plan, publish, monitor, and optimize every event from one command center.
          </p>
          <div class="auth-kpis">
            <div class="kpi-card">
              <h3>99.9%</h3>
              <p>Reliable API uptime</p>
            </div>
            <div class="kpi-card">
              <h3>Real-Time</h3>
              <p>Bookings and check-ins</p>
            </div>
          </div>
        </section>

        <section class="auth-form-wrap card card-body">
          <h2 class="mb-1">Sign In</h2>
          <p class="muted mb-4">Welcome back to your workspace.</p>
          <form [formGroup]="form" (ngSubmit)="submit()">
            <div class="mb-3">
              <label class="form-label fw-semibold">Email</label>
              <input class="form-control" type="email" formControlName="email"
                placeholder="you@example.com" autocomplete="username" />
            </div>
            <div class="mb-3">
              <label class="form-label fw-semibold">Password</label>
              <input class="form-control" type="password" formControlName="password"
                placeholder="Password" autocomplete="current-password" />
            </div>
            <button class="btn btn-primary w-100" [disabled]="form.invalid || loading">
              <span *ngIf="loading" class="spinner-border spinner-border-sm me-2"></span>
              {{ loading ? 'Signing in...' : 'Sign In' }}
            </button>
            <div class="alert alert-danger mt-3 py-2 mb-0" *ngIf="error">{{ error }}</div>
            <p class="mt-3 mb-0 text-center muted">
              No account? <a routerLink="/auth/register">Register here</a>
            </p>
          </form>
        </section>
      </div>
    </div>
  `
})
export class LoginPageComponent implements OnInit {
  private readonly fb = inject(FormBuilder);
  private readonly authService = inject(AuthService);
  private readonly router = inject(Router);

  loading = false;
  error = '';

  readonly form = this.fb.group({
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(6)]]
  });

  ngOnInit(): void {
    if (this.authService.isAuthenticated()) {
      const role = this.authService.userRole();
      this.router.navigateByUrl(role === 'Admin' ? '/admin' : '/events');
    }
  }

  submit(): void {
    if (this.form.invalid) return;
    this.loading = true;
    this.error = '';

    this.authService
      .login(this.form.getRawValue() as { email: string; password: string })
      .pipe(finalize(() => (this.loading = false)))
      .subscribe({
      next: (response) => {
        const target = response.role === 'Admin' ? '/admin' : '/events';
        console.log('NAVIGATION START', { target, role: response.role, userId: response.userId });
        void this.router
          .navigateByUrl(target)
          .then((result) => {
            console.log('NAVIGATION RESULT', { target, success: result });
            if (!result) {
              this.error = 'Navigation was canceled by route protection.';
            }
          })
          .catch((navError) => {
            console.error('NAVIGATION ERROR', navError);
            this.error = 'Login succeeded but navigation failed.';
          });
      },
      error: (err) => {
        this.error = err?.error?.error ?? err?.message ?? 'Login failed. Check your credentials.';
      }
    });
  }
}
