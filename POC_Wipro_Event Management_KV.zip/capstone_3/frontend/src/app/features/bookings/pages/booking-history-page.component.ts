import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BookingService } from '../../../core/services/booking.service';
import { BookingResponse } from '../../../core/models/booking.models';
import { finalize } from 'rxjs/operators';
import { PaymentService } from '../../../core/services/payment.service';

@Component({
  selector: 'app-booking-history-page',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="container py-4 py-md-5">
      <section class="surface-card p-4 p-md-5 mb-4">
        <h2 class="mb-1">Booking History</h2>
        <p class="muted mb-0">Track your tickets, check-in status, and upcoming sessions.</p>
      </section>

      <div *ngIf="loading" class="text-muted mb-3">
        <span class="spinner-border spinner-border-sm me-2"></span>
        Loading bookings...
      </div>

      <div *ngIf="error" class="alert alert-danger">{{ error }}</div>
      <div *ngIf="success" class="alert alert-success">{{ success }}</div>

      <div *ngIf="!loading && !error && history.length === 0" class="text-muted mb-3">
        No bookings yet.
      </div>

      <div class="surface-card p-3 p-md-4 table-responsive">
        <table class="table align-middle mb-0">
          <thead>
            <tr>
              <th>Event</th>
              <th>Start</th>
              <th>Ticket</th>
              <th>Status</th>
              <th>Check-In</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <tr *ngFor="let item of history">
              <td>{{ item.eventTitle }}</td>
              <td>{{ item.eventStartDateUtc | date:'medium' }}</td>
              <td><code>{{ item.ticketNumber }}</code></td>
              <td>
                <span class="badge"
                  [class.bg-warning]="item.status === 'Pending'"
                  [class.bg-success]="item.status === 'Booked'"
                  [class.bg-danger]="item.status === 'Declined'"
                  [class.bg-secondary]="item.status === 'Cancelled'">
                  {{ item.status }}
                </span>
              </td>
              <td>{{ item.checkedInAtUtc ? (item.checkedInAtUtc | date:'medium') : 'Pending' }}</td>
              <td>
                <button class="btn btn-outline-primary btn-sm me-2" *ngIf="item.status === 'Pending'" [disabled]="processingPaymentId === item.bookingId" (click)="payNow(item.bookingId)">
                  {{ processingPaymentId === item.bookingId ? 'Processing...' : 'Pay Now' }}
                </button>
                <button class="btn btn-outline-danger btn-sm" *ngIf="item.status === 'Pending' || item.status === 'Booked'" (click)="cancel(item.bookingId)">Cancel</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  `
})
export class BookingHistoryPageComponent implements OnInit {
  history: BookingResponse[] = [];
  loading = false;
  error = '';
  success = '';
  processingPaymentId = '';

  constructor(
    private readonly bookingService: BookingService,
    private readonly paymentService: PaymentService
  ) {}

  ngOnInit(): void {
    this.load();
  }

  cancel(bookingId: string): void {
    this.success = '';
    this.bookingService.cancel(bookingId).subscribe(() => this.load());
  }

  payNow(bookingId: string): void {
    this.error = '';
    this.success = '';
    this.processingPaymentId = bookingId;

    this.paymentService.createOrder({ bookingId }).subscribe({
      next: (order) => {
        this.paymentService
          .complete({
            providerOrderId: order.providerOrderId,
            providerPaymentId: `SIM-PAY-${Date.now()}`,
            success: true
          })
          .pipe(finalize(() => (this.processingPaymentId = '')))
          .subscribe({
            next: () => {
              this.success = 'Payment successful. Your booking can now be approved by admin.';
              this.load();
            },
            error: (err) => {
              this.error = err?.error?.error ?? err?.message ?? 'Payment completion failed.';
            }
          });
      },
      error: (err) => {
        this.processingPaymentId = '';
        this.error = err?.error?.error ?? err?.message ?? 'Failed to create payment order.';
      }
    });
  }

  private load(): void {
    this.loading = true;
    this.error = '';
    this.bookingService
      .history()
      .pipe(finalize(() => (this.loading = false)))
      .subscribe({
        next: (history) => {
          this.history = history;
        },
        error: (err) => {
          this.error = err?.error?.error ?? err?.message ?? 'Failed to load booking history.';
        }
      });
  }
}
