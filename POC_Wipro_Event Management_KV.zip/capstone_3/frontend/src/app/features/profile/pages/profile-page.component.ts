import { CommonModule } from '@angular/common';
import { Component, OnInit, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ProfileService } from '../../../core/services/profile.service';
import { UserProfile } from '../../../core/models/profile.models';
import { finalize } from 'rxjs/operators';

@Component({
  selector: 'app-profile-page',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  template: `
    <div class="container py-4 py-md-5" style="max-width: 860px;">
      <section class="surface-card p-4 p-md-5">
      <h2 class="mb-1">My Profile</h2>
      <p class="muted mb-4">Manage personal details and role visibility.</p>
      <div *ngIf="loading" class="text-muted mb-3">
        <span class="spinner-border spinner-border-sm me-2"></span>
        Loading profile...
      </div>
      <div *ngIf="error" class="alert alert-danger">{{ error }}</div>
      <form [formGroup]="form" (ngSubmit)="save()">
        <div class="row g-3">
          <div class="col-md-6">
            <label class="form-label">Full Name</label>
            <input class="form-control" formControlName="fullName" />
          </div>
          <div class="col-md-6">
            <label class="form-label">Email</label>
            <input class="form-control" [value]="profile?.email" disabled />
          </div>
          <div class="col-md-6">
            <label class="form-label">Role</label>
            <input class="form-control" [value]="profile?.role" disabled />
          </div>
        </div>
        <div class="mt-4 d-flex align-items-center gap-3">
          <button class="btn btn-primary px-4" [disabled]="form.invalid || saving">Save Profile</button>
          <span class="text-success" *ngIf="saved">Saved</span>
        </div>
      </form>

      <hr class="my-4" />

      <div>
        <h5 class="mb-2">Request Role Upgrade</h5>
        <p class="muted mb-3">Request Organizer or Admin role. An Admin must approve your request.</p>
        <div class="d-flex flex-wrap gap-2 align-items-center">
          <select class="form-select" style="max-width:260px" [(ngModel)]="requestedRole" [ngModelOptions]="{standalone: true}">
            <option value="Organizer">Organizer</option>
            <option value="Admin">Admin</option>
          </select>
          <button class="btn btn-outline-primary" type="button" [disabled]="requestingRole" (click)="requestRoleChange()">
            {{ requestingRole ? 'Submitting...' : 'Submit Request' }}
          </button>
        </div>
        <div class="text-success mt-2" *ngIf="requestRoleSuccess">{{ requestRoleSuccess }}</div>
        <div class="text-danger mt-2" *ngIf="requestRoleError">{{ requestRoleError }}</div>
      </div>
      </section>
    </div>
  `
})
export class ProfilePageComponent implements OnInit {
  private readonly fb = inject(FormBuilder);
  private readonly profileService = inject(ProfileService);

  profile: UserProfile | null = null;
  loading = false;
  error = '';
  saving = false;
  saved = false;
  requestingRole = false;
  requestedRole: 'Organizer' | 'Admin' = 'Organizer';
  requestRoleSuccess = '';
  requestRoleError = '';

  readonly form = this.fb.group({
    fullName: ['', [Validators.required, Validators.minLength(2)]]
  });

  ngOnInit(): void {
    this.loading = true;
    this.error = '';
    this.profileService
      .getProfile()
      .pipe(finalize(() => (this.loading = false)))
      .subscribe({
        next: (profile) => {
          this.profile = profile;
          this.form.patchValue({ fullName: profile.fullName });
        },
        error: (err) => {
          this.error = err?.error?.error ?? err?.message ?? 'Failed to load profile.';
        }
      });
  }

  save(): void {
    if (this.form.invalid) {
      return;
    }

    this.saving = true;
    this.saved = false;
    this.error = '';
    this.profileService
      .updateProfile({ fullName: this.form.getRawValue().fullName ?? '' })
      .pipe(finalize(() => (this.saving = false)))
      .subscribe({
        next: (profile) => {
          this.profile = profile;
          this.saved = true;
        },
        error: (err) => {
          this.error = err?.error?.error ?? err?.message ?? 'Failed to save profile.';
        }
      });
  }

  requestRoleChange(): void {
    this.requestRoleSuccess = '';
    this.requestRoleError = '';
    this.requestingRole = true;

    this.profileService
      .requestRoleChange({ role: this.requestedRole })
      .pipe(finalize(() => (this.requestingRole = false)))
      .subscribe({
        next: () => {
          this.requestRoleSuccess = 'Role request submitted successfully.';
        },
        error: (err) => {
          this.requestRoleError = err?.error?.error ?? err?.message ?? 'Failed to submit role request.';
        }
      });
  }
}
