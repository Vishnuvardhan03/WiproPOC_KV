import { Component, OnInit, OnDestroy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Subject, debounceTime, distinctUntilChanged, switchMap, catchError, of, takeUntil, tap } from 'rxjs';
import { EventService } from '../../../core/services/event.service';
import { EventResponse, OrganizerEventsDashboard } from '../../../core/models/event.models';
import { BookingService } from '../../../core/services/booking.service';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-events-page',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="container py-4 py-md-5">
      <section class="surface-card p-4 p-md-5 mb-4">
        <div class="d-flex flex-column flex-md-row gap-3 justify-content-between align-items-md-center">
          <div>
            <h2 class="mb-1">Event Catalog</h2>
            <p class="muted mb-0">Discover, manage, and book events in one place.</p>
          </div>
          <div class="search-wrap">
            <input class="form-control" placeholder="Search by title, organizer, or location"
              [(ngModel)]="query" (ngModelChange)="onQueryChange($event)" />
          </div>
        </div>
      </section>

      <div class="row g-3" *ngIf="!loading && !error && events.length > 0">
        <div class="col-lg-4 col-md-6" *ngFor="let event of events">
          <article class="surface-card p-3 h-100 d-flex flex-column">
            <div class="d-flex justify-content-between align-items-start gap-2">
              <h5 class="mb-1">{{ event.title }}</h5>
              <span class="badge bg-light text-dark border">{{ event.confirmedBookings }}/{{ event.capacity }}</span>
            </div>
            <p class="muted mb-2">{{ event.location }} • {{ event.startDateUtc | date:'mediumDate' }}</p>
            <p class="mb-3 muted">{{ event.description }}</p>
            <div class="d-flex align-items-center gap-2 mb-3">
              <span class="badge bg-success" *ngIf="event.confirmedBookings < event.capacity">Available</span>
              <span class="badge bg-danger" *ngIf="event.confirmedBookings >= event.capacity">Full</span>
              <span class="badge bg-info text-dark">INR {{ event.priceInRupees | number:'1.0-2' }}</span>
              <span class="muted">Organizer: {{ event.organizerName }}</span>
            </div>
            <div class="d-flex gap-2 flex-wrap mt-auto">
              <button class="btn btn-primary btn-sm"
                *ngIf="canBook && event.confirmedBookings < event.capacity"
                (click)="book(event.id)">
                Book Seat
              </button>
              <button class="btn btn-outline-warning btn-sm"
                *ngIf="(canManage && event.organizerId === currentUserId) || isAdmin"
                (click)="editEvent(event)">
                Edit
              </button>
              <button class="btn btn-outline-danger btn-sm"
                *ngIf="(canManage && event.organizerId === currentUserId) || isAdmin"
                (click)="deleteEvent(event.id)">
                Delete
              </button>
            </div>
          </article>
        </div>
      </div>

      <div *ngIf="loading" class="text-center py-5 text-muted">
        <div class="spinner-border spinner-border-sm me-2"></div>
        Loading events...
      </div>

      <div *ngIf="error" class="alert alert-danger">{{ error }}</div>

      <div *ngIf="success" class="alert alert-success">{{ success }}</div>

      <div *ngIf="!loading && !error && events.length === 0" class="text-center text-muted py-5">
        No events found.
      </div>

      <!-- Create / Edit Event modal (shown inline) -->
      <div class="mt-5" *ngIf="canManage || isAdmin">
        <h5 class="mb-3">{{ editingEvent ? 'Edit Event' : 'Create New Event' }}</h5>
        <form class="surface-card p-4" style="max-width:680px" (ngSubmit)="saveEvent()">
          <div class="mb-3">
            <label class="form-label">Title</label>
            <input class="form-control" [(ngModel)]="form.title" name="title" required />
          </div>
          <div class="mb-3">
            <label class="form-label">Description</label>
            <textarea class="form-control" rows="3" [(ngModel)]="form.description" name="description" required></textarea>
          </div>
          <div class="mb-3">
            <label class="form-label">Location</label>
            <input class="form-control" [(ngModel)]="form.location" name="location" required />
          </div>
          <div class="row">
            <div class="col mb-3">
              <label class="form-label">Start Date &amp; Time (UTC)</label>
              <input class="form-control" type="datetime-local" [(ngModel)]="form.startDateLocal" name="startDate" required />
            </div>
            <div class="col mb-3">
              <label class="form-label">End Date &amp; Time (UTC)</label>
              <input class="form-control" type="datetime-local" [(ngModel)]="form.endDateLocal" name="endDate" required />
            </div>
          </div>
          <div class="mb-3">
            <label class="form-label">Capacity</label>
            <input class="form-control" type="number" min="1" [(ngModel)]="form.capacity" name="capacity" required />
          </div>
          <div class="mb-3">
            <label class="form-label">Price (INR)</label>
            <input class="form-control" type="number" min="0" step="0.01" [(ngModel)]="form.priceInRupees" name="priceInRupees" required />
          </div>
          <div class="text-danger mb-2" *ngIf="formError">{{ formError }}</div>
          <div class="d-flex gap-2">
            <button class="btn btn-success" type="submit">{{ editingEvent ? 'Update' : 'Create' }}</button>
            <button class="btn btn-secondary" type="button" *ngIf="editingEvent" (click)="cancelEdit()">Cancel</button>
          </div>
        </form>
      </div>

      <section class="surface-card p-4 mt-5" *ngIf="canManage || isAdmin">
        <h5 class="mb-1">Organizer Dashboard</h5>
        <p class="muted mb-3">Your upcoming and past events with booked users.</p>

        <div class="row g-4">
          <div class="col-lg-6">
            <h6 class="mb-2">Upcoming Events</h6>
            <div *ngFor="let event of organizerDashboard?.upcomingEvents" class="border rounded p-3 mb-3">
              <div class="fw-semibold">{{ event.title }}</div>
              <div class="muted small mb-2">{{ event.startDateUtc | date:'medium' }} • {{ event.location }} • INR {{ event.priceInRupees | number:'1.0-2' }}</div>
              <div *ngIf="event.attendees.length === 0" class="muted small">No attendees yet.</div>
              <ul class="mb-0 small" *ngIf="event.attendees.length > 0">
                <li *ngFor="let attendee of event.attendees">{{ attendee.fullName }} ({{ attendee.email }}) - {{ attendee.bookingStatus }}</li>
              </ul>
            </div>
          </div>
          <div class="col-lg-6">
            <h6 class="mb-2">Past Events</h6>
            <div *ngFor="let event of organizerDashboard?.pastEvents" class="border rounded p-3 mb-3">
              <div class="fw-semibold">{{ event.title }}</div>
              <div class="muted small mb-2">{{ event.startDateUtc | date:'medium' }} • {{ event.location }} • INR {{ event.priceInRupees | number:'1.0-2' }}</div>
              <div *ngIf="event.attendees.length === 0" class="muted small">No attendees recorded.</div>
              <ul class="mb-0 small" *ngIf="event.attendees.length > 0">
                <li *ngFor="let attendee of event.attendees">{{ attendee.fullName }} ({{ attendee.email }}) - {{ attendee.bookingStatus }}</li>
              </ul>
            </div>
          </div>
        </div>
      </section>
    </div>
  `
})
export class EventsPageComponent implements OnInit, OnDestroy {
  private readonly eventService   = inject(EventService);
  private readonly bookingService = inject(BookingService);
  private readonly authService    = inject(AuthService);

  events: EventResponse[] = [];
  query  = '';
  loading = false;
  error = '';
  success = '';
  formError = '';
  editingEvent: EventResponse | null = null;
  organizerDashboard: OrganizerEventsDashboard | null = null;
  form = this.blankForm();

  readonly canBook    = this.authService.hasRole(['Attendee']);
  readonly canManage  = this.authService.hasRole(['Organizer', 'Admin']);
  readonly isAdmin    = this.authService.hasRole(['Admin']);
  readonly currentUserId = this.authService.session()?.userId ?? '';

  private readonly search$ = new Subject<string>();
  private readonly destroy$ = new Subject<void>();

  ngOnInit(): void {
    // Debounce search so typing does not trigger one API call per key.
    this.search$
      .pipe(
        debounceTime(350),
        distinctUntilChanged(),
        tap(() => {
          this.loading = true;
          this.error = '';
          this.success = '';
        }),
        switchMap((q) =>
          this.eventService.search(q).pipe(
            catchError((err) => {
              this.error = err?.error?.error ?? err?.message ?? 'Failed to load events.';
              return of([] as EventResponse[]);
            })
          )
        ),
        takeUntil(this.destroy$)
      )
      .subscribe((events) => {
        this.events = events;
        this.loading = false;
      });

    this.search$.next('');

    if (this.canManage || this.isAdmin) {
      this.loadOrganizerDashboard();
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
    this.search$.complete();
  }

  onQueryChange(q: string): void {
    this.search$.next(q);
  }

  book(eventId: string): void {
    this.bookingService.book({ eventId }).subscribe({
      next: () => {
        this.success = 'Booking request sent. Waiting for admin approval.';
        this.search$.next(this.query);
        this.loadOrganizerDashboard();
      },
      error: (err) => {
        this.success = '';
        alert(err?.error?.error ?? 'Booking failed.');
      }
    });
  }

  editEvent(event: EventResponse): void {
    this.editingEvent = event;
    this.form = {
      title: event.title,
      description: event.description,
      location: event.location,
      startDateLocal: this.toLocalInput(event.startDateUtc),
      endDateLocal:   this.toLocalInput(event.endDateUtc),
      capacity: event.capacity,
      priceInRupees: event.priceInRupees
    };
  }

  cancelEdit(): void {
    this.editingEvent = null;
    this.form = this.blankForm();
    this.formError = '';
  }

  deleteEvent(eventId: string): void {
    if (!confirm('Delete this event? All bookings will be cancelled.')) return;
    this.eventService.delete(eventId).subscribe({
      next: () => this.search$.next(this.query),
      error: (err) => alert(err?.error?.error ?? 'Delete failed.')
    });
  }

  saveEvent(): void {
    this.formError = '';
    const request = {
      title:        this.form.title.trim(),
      description:  this.form.description.trim(),
      location:     this.form.location.trim(),
      startDateUtc: new Date(this.form.startDateLocal).toISOString(),
      endDateUtc:   new Date(this.form.endDateLocal).toISOString(),
      capacity:     Number(this.form.capacity),
      priceInRupees: Number(this.form.priceInRupees)
    };

    const op$ = this.editingEvent
      ? this.eventService.update(this.editingEvent.id, request)
      : this.eventService.create(request);

    op$.subscribe({
      next: () => {
        this.cancelEdit();
        this.search$.next(this.query);
        this.loadOrganizerDashboard();
      },
      error: (err) => (this.formError = err?.error?.error ?? 'Save failed.')
    });
  }

  private blankForm() {
    return { title: '', description: '', location: '', startDateLocal: '', endDateLocal: '', capacity: 50, priceInRupees: 0 };
  }

  private loadOrganizerDashboard(): void {
    this.eventService.getOrganizerDashboard().subscribe({
      next: (dashboard) => {
        this.organizerDashboard = dashboard;
      },
      error: () => {
        this.organizerDashboard = null;
      }
    });
  }

  private toLocalInput(utcString: string): string {
    const d = new Date(utcString);
    return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
  }
}
