import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth.guard';
import { roleGuard } from './core/guards/role.guard';

export const routes: Routes = [
	{
		path: '',
		pathMatch: 'full',
		redirectTo: 'events'
	},
	{
		path: 'auth/login',
		loadComponent: () => import('./features/auth/pages/login-page.component').then((m) => m.LoginPageComponent)
	},
	{
		path: 'auth/register',
		loadComponent: () => import('./features/auth/pages/register-page.component').then((m) => m.RegisterPageComponent)
	},
	{
		path: 'events',
		loadComponent: () => import('./features/events/pages/events-page.component').then((m) => m.EventsPageComponent)
	},
	{
		path: 'bookings',
		canActivate: [authGuard, roleGuard],
		data: { roles: ['Attendee', 'Admin'] },
		loadComponent: () =>
			import('./features/bookings/pages/booking-history-page.component').then((m) => m.BookingHistoryPageComponent)
	},
	{
		path: 'profile',
		canActivate: [authGuard],
		loadComponent: () => import('./features/profile/pages/profile-page.component').then((m) => m.ProfilePageComponent)
	},
	{
		path: 'admin',
		canActivate: [authGuard, roleGuard],
		data: { roles: ['Admin'] },
		loadComponent: () => import('./features/admin/pages/admin-dashboard-page.component').then((m) => m.AdminDashboardPageComponent)
	},
	{
		path: '**',
		redirectTo: 'events'
	}
];
