import { Component, EffectRef, OnDestroy, effect } from '@angular/core';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { AuthService } from './core/services/auth.service';
import { NotificationService } from './core/services/notification.service';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, RouterLink],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class App {
  notificationsOpen = false;
  private readonly notificationEffect: EffectRef;

  constructor(
    protected readonly authService: AuthService,
    protected readonly notificationService: NotificationService,
    private readonly router: Router
  ) {
    this.notificationEffect = effect(() => {
      const isAuthenticated = this.authService.isAuthenticated();
      if (isAuthenticated) {
        this.notificationService.load().subscribe({ error: () => undefined });
        void this.notificationService.connect();
      } else {
        void this.notificationService.disconnect();
      }
    });
  }

  ngOnDestroy(): void {
    this.notificationEffect.destroy();
    void this.notificationService.disconnect();
  }

  logout(): void {
    void this.notificationService.disconnect();
    this.authService.logout();
    this.router.navigateByUrl('/auth/login');
  }

  toggleNotifications(): void {
    this.notificationsOpen = !this.notificationsOpen;
  }

  markNotificationAsRead(notificationId: string): void {
    this.notificationService.markAsRead(notificationId).subscribe({ error: () => undefined });
  }
}
